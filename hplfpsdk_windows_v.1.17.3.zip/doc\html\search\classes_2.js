var searchData=
[
  ['metricdistance',['MetricDistance',['../d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html',1,'HPLFPSDK::Types::MetricDistance'],['../d4/dd5/structMetricDistance.html',1,'MetricDistance']]]
];
