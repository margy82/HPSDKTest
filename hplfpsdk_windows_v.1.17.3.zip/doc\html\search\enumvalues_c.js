var searchData=
[
  ['overcoat_5foff',['OVERCOAT_OFF',['../d8/dcb/classHPLFPSDK_1_1Types.html#aa1b1e5608ae4f8dacacbca86d4be3a6ba48858da9ac29e2120ca034dc4c1e3c20',1,'HPLFPSDK::Types::OVERCOAT_OFF()'],['../d9/d49/types_8h.html#a282236f4ec55f59c5dd6ac4def166a18a2622ed4336782700a00e7f61b3ae73ab',1,'OVERCOAT_OFF():&#160;types.h']]],
  ['overcoat_5fon',['OVERCOAT_ON',['../d8/dcb/classHPLFPSDK_1_1Types.html#aa1b1e5608ae4f8dacacbca86d4be3a6ba52151b2e016dfe53ead6c9a8a10c1665',1,'HPLFPSDK::Types::OVERCOAT_ON()'],['../d9/d49/types_8h.html#a282236f4ec55f59c5dd6ac4def166a18a30c8ee986f9bc4514765d33af78f015d',1,'OVERCOAT_ON():&#160;types.h']]]
];
