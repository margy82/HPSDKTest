var classHPLFPSDK_1_1IJobPacker_1_1IMemoryHandler =
[
    [ "acquireBuffer", "dc/dd2/classHPLFPSDK_1_1IJobPacker_1_1IMemoryHandler.html#ab1d90f939618ae645d8dc9fb4ece751c", null ],
    [ "releaseBuffer", "dc/dd2/classHPLFPSDK_1_1IJobPacker_1_1IMemoryHandler.html#ae40219bc92d56d5c8eed9a7c91a3eec4", null ]
];