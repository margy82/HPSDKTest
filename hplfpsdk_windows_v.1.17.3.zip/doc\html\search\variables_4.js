var searchData=
[
  ['time_5fhi_5fand_5fversion',['time_hi_and_version',['../d0/d97/struct__HPLFPSDK__GUID.html#a860f0be418c7745047c4fe5a94a323da',1,'_HPLFPSDK_GUID']]],
  ['time_5flow',['time_low',['../d0/d97/struct__HPLFPSDK__GUID.html#a6a07abc39afe23d0c598c6b10ab5471d',1,'_HPLFPSDK_GUID']]],
  ['time_5fmid',['time_mid',['../d0/d97/struct__HPLFPSDK__GUID.html#a236af0b0c05c59b797c959d5804b6e14',1,'_HPLFPSDK_GUID']]]
];
