var searchData=
[
  ['remote_20manager_20object',['Remote Manager Object',['../d4/d74/page_remoteManager.html',1,'']]]
];
