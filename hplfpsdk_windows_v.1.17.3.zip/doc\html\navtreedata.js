var NAVTREE =
[
  [ "HP LFP Status & Raster Library", "index.html", [
    [ "Software Development Kit for HP Large format Printers.", "index.html", [
      [ "HP LFP Status and Raster Library Overview.", "index.html#section_overview", null ],
      [ "HP LFP Status and Raster Library Supported Functionality", "index.html#section_functionality_supported", null ]
    ] ],
    [ "API Reference", "d0/db2/page_API_documentation.html", [
      [ "API Classes", "annotated.html", [
        [ "Data Structures", "annotated.html", "annotated_dup" ],
        [ "Data Fields", "functions.html", [
          [ "All", "functions.html", "functions_dup" ],
          [ "Functions", "functions_func.html", "functions_func" ],
          [ "Variables", "functions_vars.html", null ],
          [ "Typedefs", "functions_type.html", null ],
          [ "Enumerations", "functions_enum.html", null ],
          [ "Enumerator", "functions_eval.html", "functions_eval" ]
        ] ]
      ] ],
      [ "API Methods", "df/de6/group__API__C__Methods.html", null ],
      [ "API Schemas", "usergroup0.html", [
        [ "IDevice schemas", "d7/d95/page_device.html", null ],
        [ "IAccountingManager schemas", "d8/d8b/page_accountingManager.html", null ],
        [ "IInfoManager schemas", "d3/d36/page_infoManager.html", null ],
        [ "IMediaManager schemas", "d7/d9d/page_mediaManager.html", null ],
        [ "IRemoteManager schemas", "d4/d74/page_remoteManager.html", null ],
        [ "IUsageManager schemas", "d7/ddc/page_usageManager.html", null ]
      ] ]
    ] ],
    [ "Appendix", "dd/dba/page_appendix_UUID_format.html", [
      [ "UUID format", "dd/dba/page_appendix_UUID_format.html", null ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"d8/dcb/classHPLFPSDK_1_1Types.html#a0ea75a7b5d07150e8244c40eb43fc15fae6fcbdd3bf9686fee051915223f74a7d",
"d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca038239d952699ec4fb9322dda4feb09e",
"d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a26a97a69f73c8e91bf2bace5a097bcfb",
"functions_func_u.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';