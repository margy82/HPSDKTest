README

1. Included:
- hplfpsdk-test.exe 32 and 64 bits for windows
- this README


2. Command Line Arguments
- The hplfpsdk-test needs the printer or pc-target IP with a valid firmware version
and the printer model that is supposed to be loaded.
	Example:  hplfpsdk-test 192.168.1.1 "HP DesignJet T1700"
	
3. Installation instructions.
- The hplfpsdk-test as any HP LFP SDK client application needs to load the
hplfpsdk.dll dynamic library and it dependencies
(hppihost.dll HPLFPStreamRasterLibrary.dll and iconv.dll)
Please be sure they are accesible using the PATH environment variable or
copy them to this directory.

IMPORTANT NOTE!!!
Be aware to copy the correct libraries accordingly to the platform.
So copy the lib32/*.dll files to bin32/ 
where the hplfpsdk-test 32 bits version is located.
And copy the lib64/*.dll files to bin64/
where the hplfpsdk-test 64 bits version is located.

- Also the hplfpsdk-test and the client applications needs the Data and Tiff_Images folders
to be located on the same execution folder. Please copy res/Data and res/Tiff_Images folders
and their content to this path.
