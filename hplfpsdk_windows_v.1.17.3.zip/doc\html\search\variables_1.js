var searchData=
[
  ['clock_5fseq_5fhi_5fand_5freserved',['clock_seq_hi_and_reserved',['../d0/d97/struct__HPLFPSDK__GUID.html#a0efcdc70d559bebc97d1c9a5284502a7',1,'_HPLFPSDK_GUID']]],
  ['clock_5fseq_5flow',['clock_seq_low',['../d0/d97/struct__HPLFPSDK__GUID.html#a80b44432ff2ff91fec0c9bcb49635981',1,'_HPLFPSDK_GUID']]]
];
