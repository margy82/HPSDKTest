var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvwxy~",
  1: "_imprt",
  2: "h",
  3: "ahimptu",
  4: "acdefghijmnprstuw~",
  5: "bcintu",
  6: "hnopt",
  7: "bcdefghijlmoprsuvwy",
  8: "bcdefghijklmoprsuvwxy",
  9: "h",
  10: "gh",
  11: "ahimrsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Modules",
  11: "Pages"
};

