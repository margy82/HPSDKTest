var classHPLFPSDK_1_1IJobPacker_1_1Preview =
[
    [ "Preview", "df/dcf/classHPLFPSDK_1_1IJobPacker_1_1Preview.html#a04d1f64c6c95c4a6b9e3188aac0e78af", null ],
    [ "buffer_", "df/dcf/classHPLFPSDK_1_1IJobPacker_1_1Preview.html#aac27da80e78423a423b935da5dd5bec4", null ],
    [ "numBytes_", "df/dcf/classHPLFPSDK_1_1IJobPacker_1_1Preview.html#aaa96cd96f87b42aa0733196ff93614bb", null ]
];