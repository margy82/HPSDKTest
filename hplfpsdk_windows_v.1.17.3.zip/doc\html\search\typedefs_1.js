var searchData=
[
  ['numcopies',['NumCopies',['../d8/dcb/classHPLFPSDK_1_1Types.html#a51c4781d42c5da9700c0f3cb2bd5eab3',1,'HPLFPSDK::Types::NumCopies()'],['../d9/d49/types_8h.html#aa963a440aaa1994616f4794f408ad4a8',1,'NumCopies():&#160;types.h']]]
];
