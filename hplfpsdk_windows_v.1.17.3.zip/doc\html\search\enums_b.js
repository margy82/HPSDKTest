var searchData=
[
  ['overcoat',['Overcoat',['../d8/dcb/classHPLFPSDK_1_1Types.html#aa1b1e5608ae4f8dacacbca86d4be3a6b',1,'HPLFPSDK::Types::Overcoat()'],['../d9/d49/types_8h.html#a282236f4ec55f59c5dd6ac4def166a18',1,'Overcoat():&#160;types.h']]]
];
