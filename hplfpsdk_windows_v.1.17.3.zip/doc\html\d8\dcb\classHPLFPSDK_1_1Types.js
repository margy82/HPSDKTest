var classHPLFPSDK_1_1Types =
[
    [ "MetricDistance", "d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html", "d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance" ],
    [ "NumCopies", "d8/dcb/classHPLFPSDK_1_1Types.html#a51c4781d42c5da9700c0f3cb2bd5eab3", null ],
    [ "PrivacyPin", "d8/dcb/classHPLFPSDK_1_1Types.html#af1c003cfb859a18313a83b219675f4fe", null ],
    [ "BooleanPlusDefault", "d8/dcb/classHPLFPSDK_1_1Types.html#a46dfc76761bdc9bd07ebfcbd24df31a6", [
      [ "BOOLEANPLUSDEFAULT_BOOLEAN_FALSE", "d8/dcb/classHPLFPSDK_1_1Types.html#a46dfc76761bdc9bd07ebfcbd24df31a6a9d23de583e46daf69a205ab0b7b69a14", null ],
      [ "BOOLEANPLUSDEFAULT_BOOLEAN_TRUE", "d8/dcb/classHPLFPSDK_1_1Types.html#a46dfc76761bdc9bd07ebfcbd24df31a6a35b4234d2f695e8ffe2c5ce28511778e", null ],
      [ "BOOLEANPLUSDEFAULT_BOOLEAN_DEFAULT", "d8/dcb/classHPLFPSDK_1_1Types.html#a46dfc76761bdc9bd07ebfcbd24df31a6a601a80e7c512aa9d70f2c9edcfc5ac02", null ]
    ] ],
    [ "BorderlessMethod", "d8/dcb/classHPLFPSDK_1_1Types.html#a7c0b4e1c6b91c90f18802de6c7ed6fce", [
      [ "BORDERLESSMETHOD_AUTOFIT", "d8/dcb/classHPLFPSDK_1_1Types.html#a7c0b4e1c6b91c90f18802de6c7ed6fceabe2c9908ad5df8ab87d5658ff13de470", null ],
      [ "BORDERLESSMETHOD_CROP", "d8/dcb/classHPLFPSDK_1_1Types.html#a7c0b4e1c6b91c90f18802de6c7ed6fceac1be25bbd1ebdb1241275914f5893e13", null ]
    ] ],
    [ "CalibrationDestinationType", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e2c258b3b2ebacc83eb696b9f599057", [
      [ "CALIBRATION_DESTINATION_BASKET", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e2c258b3b2ebacc83eb696b9f599057ad9ebc6cb258fc48f62daeffc2f3af66c", null ],
      [ "CALIBRATION_DESTINATION_STACKER", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e2c258b3b2ebacc83eb696b9f599057ac4529e7e35fa914c48c9ca10aae05c22", null ]
    ] ],
    [ "CalibrationType", "d8/dcb/classHPLFPSDK_1_1Types.html#a74a27be223b0c38e53af799c4d4252a7", [
      [ "CALIBRATION_COLOR", "d8/dcb/classHPLFPSDK_1_1Types.html#a74a27be223b0c38e53af799c4d4252a7af045e29417420c486db02ceb7a57aedf", null ],
      [ "CALIBRATION_ALIGNMENT", "d8/dcb/classHPLFPSDK_1_1Types.html#a74a27be223b0c38e53af799c4d4252a7aac6e7b5d35ede9c205ae7beabdeca6ea", null ],
      [ "CALIBRATION_ADVANCE", "d8/dcb/classHPLFPSDK_1_1Types.html#a74a27be223b0c38e53af799c4d4252a7a03b021c5b25ea5785e833c734c51f912", null ]
    ] ],
    [ "ColorMode", "d8/dcb/classHPLFPSDK_1_1Types.html#aa288b5e87f4a7388ba9efa735331cae4", [
      [ "COLORMODE_UNDEFINED", "d8/dcb/classHPLFPSDK_1_1Types.html#aa288b5e87f4a7388ba9efa735331cae4a69cbfff54eb9d0149623bcee4f194358", null ],
      [ "COLORMODE_CMYK", "d8/dcb/classHPLFPSDK_1_1Types.html#aa288b5e87f4a7388ba9efa735331cae4ab996d73257be0cb08ccb4e80e810189a", null ],
      [ "COLORMODE_CMYKLITES", "d8/dcb/classHPLFPSDK_1_1Types.html#aa288b5e87f4a7388ba9efa735331cae4ac9096e5b07d1a40a6c25b14df920c685", null ],
      [ "COLORMODE_CMYKLITESW", "d8/dcb/classHPLFPSDK_1_1Types.html#aa288b5e87f4a7388ba9efa735331cae4afebc9bde7902d6ea0f3fead659b851b7", null ]
    ] ],
    [ "ColorSpace", "d8/dcb/classHPLFPSDK_1_1Types.html#a3d6269431e410b3be99582b49745fde5", [
      [ "COLORSPACE_COLORSPACE_SRGB", "d8/dcb/classHPLFPSDK_1_1Types.html#a3d6269431e410b3be99582b49745fde5aef4943d08918adde927620cec64ffea9", null ],
      [ "COLORSPACE_COLORSPACE_DEVICECALIBRATED", "d8/dcb/classHPLFPSDK_1_1Types.html#a3d6269431e410b3be99582b49745fde5a01fcc7b795c1f1c5622558ef76601c5a", null ]
    ] ],
    [ "ContentAlignment", "d8/dcb/classHPLFPSDK_1_1Types.html#ad776a696031ff6484b616b16f4ac6ba5", [
      [ "CONTENTALIGNMENT_LEFT", "d8/dcb/classHPLFPSDK_1_1Types.html#ad776a696031ff6484b616b16f4ac6ba5ae039f9a02aebb9d8958becf7059569c5", null ],
      [ "CONTENTALIGNMENT_CENTER", "d8/dcb/classHPLFPSDK_1_1Types.html#ad776a696031ff6484b616b16f4ac6ba5aefb8184704839d6cf37374755340cfca", null ],
      [ "CONTENTALIGNMENT_RIGHT", "d8/dcb/classHPLFPSDK_1_1Types.html#ad776a696031ff6484b616b16f4ac6ba5ac7abc1890a82226bd128396f06ac422b", null ],
      [ "CONTENTALIGNMENT_ALIGN_TO_PLATTEN", "d8/dcb/classHPLFPSDK_1_1Types.html#ad776a696031ff6484b616b16f4ac6ba5aaec66cd3aeeebd184af5878894029e6e", null ]
    ] ],
    [ "Cutter", "d8/dcb/classHPLFPSDK_1_1Types.html#adde406bbee2a71ea5f7ebcdec30b8c76", [
      [ "CUTTER_DISABLED", "d8/dcb/classHPLFPSDK_1_1Types.html#adde406bbee2a71ea5f7ebcdec30b8c76a1d7d7324bb9cb932b5e981e43aa01613", null ],
      [ "CUTTER_ENABLED", "d8/dcb/classHPLFPSDK_1_1Types.html#adde406bbee2a71ea5f7ebcdec30b8c76acbf785be83ae5251c50f0ee69f03decf", null ],
      [ "CUTTER_JOB_DISABLED", "d8/dcb/classHPLFPSDK_1_1Types.html#adde406bbee2a71ea5f7ebcdec30b8c76ae9b07a9ef0d229446a9a665141159268", null ]
    ] ],
    [ "DryTimeMode", "d8/dcb/classHPLFPSDK_1_1Types.html#a37ea8d86444408f1065c1878eef46450", [
      [ "DRYTIMEMODE_REDUCED", "d8/dcb/classHPLFPSDK_1_1Types.html#a37ea8d86444408f1065c1878eef46450a165cf7a610fba1035b174b2b92651723", null ],
      [ "DRYTIMEMODE_NORMAL", "d8/dcb/classHPLFPSDK_1_1Types.html#a37ea8d86444408f1065c1878eef46450ad373f11a51ba7b326ebe2d4c36ce9539", null ],
      [ "DRYTIMEMODE_EXTENDED", "d8/dcb/classHPLFPSDK_1_1Types.html#a37ea8d86444408f1065c1878eef46450a13b44405f50617619df3e341aad2d127", null ],
      [ "DRYTIMEMODE_NONE", "d8/dcb/classHPLFPSDK_1_1Types.html#a37ea8d86444408f1065c1878eef46450ae7ad0af50d941a102d3c7d782481ceac", null ]
    ] ],
    [ "DualSide", "d8/dcb/classHPLFPSDK_1_1Types.html#aa71ecdfa6378403ba65e6c94e8cee1a8", [
      [ "DUALSIDE_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#aa71ecdfa6378403ba65e6c94e8cee1a8a68360a87a89ac81d047d122b83d5af62", null ],
      [ "DUALSIDE_A", "d8/dcb/classHPLFPSDK_1_1Types.html#aa71ecdfa6378403ba65e6c94e8cee1a8ae31ac3dc09cc31b7db6e641a1de8918c", null ],
      [ "DUALSIDE_B", "d8/dcb/classHPLFPSDK_1_1Types.html#aa71ecdfa6378403ba65e6c94e8cee1a8aef2b8f2f75ca9ff036bcfd447d5e1325", null ]
    ] ],
    [ "DualSideOrder", "d8/dcb/classHPLFPSDK_1_1Types.html#a53e11e147e119b86527912d2c45d229e", [
      [ "DUALSIDEORDER_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#a53e11e147e119b86527912d2c45d229eaa8a28c23d7c2a665ad3cd1afdbe2ab1e", null ],
      [ "DUALSIDEORDER_INTERLEAVED", "d8/dcb/classHPLFPSDK_1_1Types.html#a53e11e147e119b86527912d2c45d229ea91190bd2f73f912712c10465c30661f1", null ],
      [ "DUALSIDEORDER_NON_INTERLEAVED", "d8/dcb/classHPLFPSDK_1_1Types.html#a53e11e147e119b86527912d2c45d229eaa2ca3269325d91d427a2f7c5c5cccda6", null ]
    ] ],
    [ "Economode", "d8/dcb/classHPLFPSDK_1_1Types.html#a0ea75a7b5d07150e8244c40eb43fc15f", [
      [ "ECONOMODE_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#a0ea75a7b5d07150e8244c40eb43fc15fa35985553dc5e8ead4492a47504c5c6d1", null ],
      [ "ECONOMODE_ON", "d8/dcb/classHPLFPSDK_1_1Types.html#a0ea75a7b5d07150e8244c40eb43fc15fae6fcbdd3bf9686fee051915223f74a7d", null ]
    ] ],
    [ "EfficiencyMode", "d8/dcb/classHPLFPSDK_1_1Types.html#ae92f33f9dcc20d0eca7992ad4d790a76", [
      [ "EFFICIENCYMODE_ON", "d8/dcb/classHPLFPSDK_1_1Types.html#ae92f33f9dcc20d0eca7992ad4d790a76a5db35ec6744794f28c02e85adc37f490", null ],
      [ "EFFICIENCYMODE_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#ae92f33f9dcc20d0eca7992ad4d790a76a59da3cf5d7af219baa548775d62777cb", null ]
    ] ],
    [ "ExtendedPM", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1e", [
      [ "EXTENDEDPM_XPM0", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea0eca3bb1eb4910142bde05f7531ab82b", null ],
      [ "EXTENDEDPM_XPM1", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea8d510124e12d6a0e14fffc8bcd02dbaa", null ],
      [ "EXTENDEDPM_XPM2", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1eadd68dfbf869e3cdba79abc15e211644b", null ],
      [ "EXTENDEDPM_XPM3", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1eab3d1d79185d5a25fb3a92f34ef4b8858", null ],
      [ "EXTENDEDPM_XPM4", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea0e3482d3fbd625ba19ea6784a6f7c5a6", null ],
      [ "EXTENDEDPM_XPM5", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea48270c169d44891f4682b52d106e6393", null ],
      [ "EXTENDEDPM_XPM6", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1eabe6cfe9f7da526f9213548c6f18563b6", null ],
      [ "EXTENDEDPM_XPM7", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea6660c7c1f6db4c08198f96cf1bef51d8", null ],
      [ "EXTENDEDPM_XPM8", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1eae66595a8e33e681f577b4c9bf6cd5ea8", null ],
      [ "EXTENDEDPM_XPM9", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea923bf81ad7f80efabdfd258cea261f27", null ],
      [ "EXTENDEDPM_XPM10", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea88919b4b2937a7b0f2438150b563043e", null ],
      [ "EXTENDEDPM_XPM11", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea243c7d5a256e5d9601b3561c95944f28", null ],
      [ "EXTENDEDPM_XPM12", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea09f3bd809a2dc25e46e568c13d48d1ff", null ],
      [ "EXTENDEDPM_XPM13", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea28297c3025959922db41fdc371c94f2b", null ],
      [ "EXTENDEDPM_XPM14", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea854ba8a3e50213eb33f2664cd18bc231", null ],
      [ "EXTENDEDPM_XPM15", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea44305a0cb41c4a7b29acbda0c4d0fc0c", null ],
      [ "EXTENDEDPM_XPM16", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea192f56254d491ed623b936dc4bbeee1b", null ],
      [ "EXTENDEDPM_XPM17", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea647db6145f9edbdcb8b464b2d92bf19e", null ],
      [ "EXTENDEDPM_XPM18", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ea7c5d2c548de6290cd87e223951d058d5", null ],
      [ "EXTENDEDPM_XPM19", "d8/dcb/classHPLFPSDK_1_1Types.html#a9708b1210f8cc9b6bf831c0bcee19f1ead55988697b51ce1d64b64ad50c144181", null ]
    ] ],
    [ "ExtraPasses", "d8/dcb/classHPLFPSDK_1_1Types.html#ae52ef4afc267f7716102872e85a31157", [
      [ "EXTRAPASSES_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#ae52ef4afc267f7716102872e85a31157aad238dc87d0ad611ea14e03f2c2b3eae", null ],
      [ "EXTRAPASSES_ON", "d8/dcb/classHPLFPSDK_1_1Types.html#ae52ef4afc267f7716102872e85a31157a9b8569b171191453fd25106661727aab", null ]
    ] ],
    [ "FlipEdge", "d8/dcb/classHPLFPSDK_1_1Types.html#ae2cdb21c559a1ddb6d777bd71b5c8308", [
      [ "FLIPEDGE_UNDEFINED", "d8/dcb/classHPLFPSDK_1_1Types.html#ae2cdb21c559a1ddb6d777bd71b5c8308a48edeac53c3f9e4583c83a37da5865f3", null ],
      [ "FLIPEDGE_LATERAL_EDGE", "d8/dcb/classHPLFPSDK_1_1Types.html#ae2cdb21c559a1ddb6d777bd71b5c8308ae2e73f8c274ed9d3ddb2db061571a708", null ],
      [ "FLIPEDGE_FRONT_EDGE", "d8/dcb/classHPLFPSDK_1_1Types.html#ae2cdb21c559a1ddb6d777bd71b5c8308a8a8300a32dc9cf07a384b9af1a3f6f80", null ]
    ] ],
    [ "FoldingStyle", "d8/dcb/classHPLFPSDK_1_1Types.html#af3e6f79620164cad7817055c1eb8ee6f", [
      [ "FOLDINGSTYLE_CUSTOM", "d8/dcb/classHPLFPSDK_1_1Types.html#af3e6f79620164cad7817055c1eb8ee6faf57990aac2f58e3684d7c0b781348b3e", null ],
      [ "FOLDINGSTYLE_STANDARD", "d8/dcb/classHPLFPSDK_1_1Types.html#af3e6f79620164cad7817055c1eb8ee6faad91bbeebc9259523e8b784746eaaff6", null ]
    ] ],
    [ "GlossEnhancer", "d8/dcb/classHPLFPSDK_1_1Types.html#a3a196242769e9fb10d23ad1a3f123dd9", [
      [ "GLOSSENHANCER_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#a3a196242769e9fb10d23ad1a3f123dd9a662dc0f7f4e8959bc6a4ffc020b40436", null ],
      [ "GLOSSENHANCER_INKEDAREA", "d8/dcb/classHPLFPSDK_1_1Types.html#a3a196242769e9fb10d23ad1a3f123dd9acbd7b98fe2f74654975a4d8532039d56", null ],
      [ "GLOSSENHANCER_FULLPAGE", "d8/dcb/classHPLFPSDK_1_1Types.html#a3a196242769e9fb10d23ad1a3f123dd9ac9c27f6b87950ebad64a740415c5d6d5", null ]
    ] ],
    [ "HighSpeed", "d8/dcb/classHPLFPSDK_1_1Types.html#a64e6e2b7c7b90cc909b79e2cfab0097e", [
      [ "HIGHSPEED_ON", "d8/dcb/classHPLFPSDK_1_1Types.html#a64e6e2b7c7b90cc909b79e2cfab0097eaaff1ba7ef5dcdf877dd0a18079b03a3b", null ],
      [ "HIGHSPEED_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#a64e6e2b7c7b90cc909b79e2cfab0097eadb91c3f296f40da597da8c160afd692e", null ]
    ] ],
    [ "InkDensity", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4ee", [
      [ "INKDENSITY_UNDEFINED", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eead51abe03b482e90b62c075687b4eb9d4", null ],
      [ "INKDENSITY_L4", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea829caa193456d367e40ac4490ed4eb99", null ],
      [ "INKDENSITY_L5", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eeadee2857fa27cda4c5d06f76040bda366", null ],
      [ "INKDENSITY_L6", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea07dccbca854a70477cb22b81bccef2c2", null ],
      [ "INKDENSITY_L7", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea81de601d39f0ef12c2e3ec1e5191869c", null ],
      [ "INKDENSITY_L8", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea3dd0331213742ccf2e0f71642bba2059", null ],
      [ "INKDENSITY_L9", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eeadbf39062e3b1f3147b01326a95b824f3", null ],
      [ "INKDENSITY_L10", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eeab3ee0bae151ecfefcf48784fb9076088", null ],
      [ "INKDENSITY_L11", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea788da5d088ac28425ee00e3b472097f8", null ],
      [ "INKDENSITY_L12", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea95b8ac56b99df06977e8535fd7a13236", null ],
      [ "INKDENSITY_L13", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eeab552c733b438c11d970ab6e0386ca402", null ],
      [ "INKDENSITY_L14", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea895cdf435ed1d08b393f2315b8516fe4", null ],
      [ "INKDENSITY_L15", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eeafca0efdd640237ecc9719aea1c64ebc9", null ],
      [ "INKDENSITY_L16", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eeaa9bbf73a09d0c4414efbca637f19bb37", null ],
      [ "INKDENSITY_L17", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eeac1c37daa4e19c9739ffda0fc640cb7f4", null ],
      [ "INKDENSITY_L18", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea69af2ca0389de0615163f0acc1c3e62e", null ],
      [ "INKDENSITY_L19", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eead28417f2732f18791a5408d8da3b44e6", null ],
      [ "INKDENSITY_L20", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eeab5b0b3b4053f153eb8e9c9ab84f61810", null ],
      [ "INKDENSITY_L21", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea723dcc910f69d9cbabc61cfed2f9ca61", null ],
      [ "INKDENSITY_L22", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea98c83183d35e52c06e2dce87b208dc7f", null ],
      [ "INKDENSITY_L23", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea131b5e5f88a56b451ea43419f4f55763", null ],
      [ "INKDENSITY_L24", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea64462b02b5ca90844a2624eb5e74d51a", null ],
      [ "INKDENSITY_L25", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea9160da3eac9ecc273e3d1a447e3c0cce", null ],
      [ "INKDENSITY_L26", "d8/dcb/classHPLFPSDK_1_1Types.html#ad702255cdf13a03dfc1885534a90b4eea43cebb37785e59a179c0f0cc66883730", null ]
    ] ],
    [ "InkDensityProfile", "d8/dcb/classHPLFPSDK_1_1Types.html#a3cf42f510ad24c170a05144a4fac20f0", [
      [ "INKDENSITYPROFILE_UNDEFINED", "d8/dcb/classHPLFPSDK_1_1Types.html#a3cf42f510ad24c170a05144a4fac20f0a9a304e33d0e3e14b435159e280621bb0", null ],
      [ "INKDENSITYPROFILE_P1", "d8/dcb/classHPLFPSDK_1_1Types.html#a3cf42f510ad24c170a05144a4fac20f0a8746a62c483552a859d4d1ac62dea593", null ],
      [ "INKDENSITYPROFILE_P2", "d8/dcb/classHPLFPSDK_1_1Types.html#a3cf42f510ad24c170a05144a4fac20f0a12eb348b496a66d31f702342574a346e", null ],
      [ "INKDENSITYPROFILE_P3", "d8/dcb/classHPLFPSDK_1_1Types.html#a3cf42f510ad24c170a05144a4fac20f0abd5a9d0eb45b64d25aa64591b089ae17", null ],
      [ "INKDENSITYPROFILE_P4", "d8/dcb/classHPLFPSDK_1_1Types.html#a3cf42f510ad24c170a05144a4fac20f0a10c34baf00f1bea5720a21146cf6b26f", null ],
      [ "INKDENSITYPROFILE_P5", "d8/dcb/classHPLFPSDK_1_1Types.html#a3cf42f510ad24c170a05144a4fac20f0adcc29c12592e1c71eddd66dbbd0b95f2", null ],
      [ "INKDENSITYPROFILE_P6", "d8/dcb/classHPLFPSDK_1_1Types.html#a3cf42f510ad24c170a05144a4fac20f0a69622ed93f54427925120a6e7354f8af", null ]
    ] ],
    [ "JobCollate", "d8/dcb/classHPLFPSDK_1_1Types.html#a9efb9a35af03fcdaaa46f33040d107f8", [
      [ "JOBCOLLATE_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#a9efb9a35af03fcdaaa46f33040d107f8a17cfa7f5e65f166934514e1b4357c71e", null ],
      [ "JOBCOLLATE_ON", "d8/dcb/classHPLFPSDK_1_1Types.html#a9efb9a35af03fcdaaa46f33040d107f8afbe7f62700297a941d1291b7ab65aace", null ]
    ] ],
    [ "JobLanguage", "d8/dcb/classHPLFPSDK_1_1Types.html#a885eb56f5a87e17c1da55d98c5a3296c", [
      [ "JOB_LANGUAGE_UNKNOWN", "d8/dcb/classHPLFPSDK_1_1Types.html#a885eb56f5a87e17c1da55d98c5a3296cabd3d98ee7d006ef54bcefac72a0d9d16", null ],
      [ "JOB_LANGUAGE_PCL3GUI", "d8/dcb/classHPLFPSDK_1_1Types.html#a885eb56f5a87e17c1da55d98c5a3296ca3e32e10cf8ca393e054abc4698d995dd", null ],
      [ "JOB_LANGUAGE_RSTREAM", "d8/dcb/classHPLFPSDK_1_1Types.html#a885eb56f5a87e17c1da55d98c5a3296cad660c40045318d7a62eb827470c44834", null ]
    ] ],
    [ "LengthUnits", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88", [
      [ "LENGTH_UNIT_NONE", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88affb045d80ae964e748e68b09b006bd51", null ],
      [ "LENGTH_UNIT_EMU", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a017444516ae9f64aa8514557d44fef97", null ],
      [ "LENGTH_UNIT_100THMM", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a97a9b3b3932f8f768b1316d9ef4483a2", null ],
      [ "LENGTH_UNIT_10THMM", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a3339c6a19ea8048c73ed60861109681d", null ],
      [ "LENGTH_UNIT_MM", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a1c9a06a1aaba874ca5ae952f367329d0", null ],
      [ "LENGTH_UNIT_CM", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88af1d11fd90a9d698d92c7f2c875120dc6", null ],
      [ "LENGTH_UNIT_M", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88ad3c5118513c27e366523546e46b7356e", null ],
      [ "LENGTH_UNIT_300THINCH", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88ae221781c99090b06d84466cf194f12f5", null ],
      [ "LENGTH_UNIT_100THINCH", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a2ffcd011232b52eb14f1adaad00bd9c3", null ],
      [ "LENGTH_UNIT_INCH", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88aeac5f9eee07e11a073bfc15fbede2bb2", null ],
      [ "LENGTH_UNIT_FEET", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a235fedf088e9eba11f7e912a919e1e16", null ],
      [ "LENGTH_UNIT_POINT", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a586abac85f64de13edb312536480da52", null ],
      [ "LENGTH_UNIT_DECIPOINT", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88add0eb3b8943af6934655e9ccb4212d26", null ],
      [ "LENGTH_UNIT_PICA", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a129f74f5b9046f8a95f6db44d5ef9a0c", null ],
      [ "LENGTH_UNIT_TWIP", "d8/dcb/classHPLFPSDK_1_1Types.html#af2c0eed7682bca45d77584310c027e88a26a97a69f73c8e91bf2bace5a097bcfb", null ]
    ] ],
    [ "LogConfigFlags", "d8/dcb/classHPLFPSDK_1_1Types.html#a56278a41f2e2293297b7a1f5df34b291", [
      [ "LOG_CONFIG_FILE_FLAG_UNAVAILABLE", "d8/dcb/classHPLFPSDK_1_1Types.html#a56278a41f2e2293297b7a1f5df34b291a4c28f444f37d767655a4db5341ce26c6", null ],
      [ "LOG_CONFIG_FILE_FLAG_AVAILABLE", "d8/dcb/classHPLFPSDK_1_1Types.html#a56278a41f2e2293297b7a1f5df34b291a4a1c2051b151d8f3ff442eec131a046a", null ]
    ] ],
    [ "LogLevel", "d8/dcb/classHPLFPSDK_1_1Types.html#a4d417db9f7375c950b0ac185f4c800f1", [
      [ "LOG_LEVEL_ALL", "d8/dcb/classHPLFPSDK_1_1Types.html#a4d417db9f7375c950b0ac185f4c800f1a4dd65bd941975a4d87717ea495e10b48", null ],
      [ "LOG_LEVEL_VERBOSE", "d8/dcb/classHPLFPSDK_1_1Types.html#a4d417db9f7375c950b0ac185f4c800f1ad19d5db9b1cd03f95ca908899bbd44e4", null ],
      [ "LOG_LEVEL_INFO", "d8/dcb/classHPLFPSDK_1_1Types.html#a4d417db9f7375c950b0ac185f4c800f1a0b2ec9a5eae85d39f28e2d6398c5b6ae", null ],
      [ "LOG_LEVEL_WARNING", "d8/dcb/classHPLFPSDK_1_1Types.html#a4d417db9f7375c950b0ac185f4c800f1a534bc997cb93dc40982db4a088295f96", null ],
      [ "LOG_LEVEL_ERROR", "d8/dcb/classHPLFPSDK_1_1Types.html#a4d417db9f7375c950b0ac185f4c800f1a6ce896f824da52c4c5bf843747d36474", null ],
      [ "LOG_LEVEL_NONE", "d8/dcb/classHPLFPSDK_1_1Types.html#a4d417db9f7375c950b0ac185f4c800f1a596ccb084a3fc2e44f13ed2b79dd5886", null ]
    ] ],
    [ "MarginLayout", "d8/dcb/classHPLFPSDK_1_1Types.html#a0456845c9940f73f1fbe113e682fe622", [
      [ "MARGINLAYOUT_STANDARD", "d8/dcb/classHPLFPSDK_1_1Types.html#a0456845c9940f73f1fbe113e682fe622a44fce0690db4273f2c6ee8c2c3c9f392", null ],
      [ "MARGINLAYOUT_OVERSIZE", "d8/dcb/classHPLFPSDK_1_1Types.html#a0456845c9940f73f1fbe113e682fe622a978e7510c6c433bf2cc037156ee7bb30", null ],
      [ "MARGINLAYOUT_CLIP_INSIDE", "d8/dcb/classHPLFPSDK_1_1Types.html#a0456845c9940f73f1fbe113e682fe622a2b3d122a6572cf26ba5e1e70811450d7", null ]
    ] ],
    [ "MarginSetting", "d8/dcb/classHPLFPSDK_1_1Types.html#a2243945738f69ba4a96c96fd5fca5268", [
      [ "MARGINSETTING_NORMAL", "d8/dcb/classHPLFPSDK_1_1Types.html#a2243945738f69ba4a96c96fd5fca5268ad2c08749131a8727b7ba8b2ff707d440", null ],
      [ "MARGINSETTING_EXTENDED", "d8/dcb/classHPLFPSDK_1_1Types.html#a2243945738f69ba4a96c96fd5fca5268a1220638a640ebb2d4e762888b09541aa", null ],
      [ "MARGINSETTING_SMALLER", "d8/dcb/classHPLFPSDK_1_1Types.html#a2243945738f69ba4a96c96fd5fca5268ad638e7ee7aa69fd01bf331f9f1fecd59", null ],
      [ "MARGINSETTING_NO_MARGINS", "d8/dcb/classHPLFPSDK_1_1Types.html#a2243945738f69ba4a96c96fd5fca5268a5adc090328b73c5c8d457977317e64c4", null ]
    ] ],
    [ "MaxDetail", "d8/dcb/classHPLFPSDK_1_1Types.html#aa37cfc4372196c301a7b11cfbe9b00ac", [
      [ "MAXDETAIL_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#aa37cfc4372196c301a7b11cfbe9b00aca9bd1b4cbd0ba1537c9e4b33701b8ec6c", null ],
      [ "MAXDETAIL_ON", "d8/dcb/classHPLFPSDK_1_1Types.html#aa37cfc4372196c301a7b11cfbe9b00aca8a789c2edc99b3b5d110dc2841dbb827", null ]
    ] ],
    [ "MediaDestination", "d8/dcb/classHPLFPSDK_1_1Types.html#a8f558c300b1b53d137cd0c145ab228f8", [
      [ "MEDIADESTINATION_AUTO", "d8/dcb/classHPLFPSDK_1_1Types.html#a8f558c300b1b53d137cd0c145ab228f8a97d036c1473fc263de6063faa4c0afd9", null ],
      [ "MEDIADESTINATION_BIN", "d8/dcb/classHPLFPSDK_1_1Types.html#a8f558c300b1b53d137cd0c145ab228f8a4289d4faa224d20835dc6ab662b79c5e", null ],
      [ "MEDIADESTINATION_ROLL", "d8/dcb/classHPLFPSDK_1_1Types.html#a8f558c300b1b53d137cd0c145ab228f8aa5ccaac1e255a6d7483c1e221ed9a3bc", null ],
      [ "MEDIADESTINATION_STACKER", "d8/dcb/classHPLFPSDK_1_1Types.html#a8f558c300b1b53d137cd0c145ab228f8a2c9ef7f4f73da669fd67d4c51a969a82", null ],
      [ "MEDIADESTINATION_FOLDER", "d8/dcb/classHPLFPSDK_1_1Types.html#a8f558c300b1b53d137cd0c145ab228f8a87f11c0c224f89097ec052613f926697", null ],
      [ "MEDIADESTINATION_ACCESSORY_STACKER", "d8/dcb/classHPLFPSDK_1_1Types.html#a8f558c300b1b53d137cd0c145ab228f8adc3d7f4941c1fe637a5d47c4badc05e3", null ],
      [ "MEDIADESTINATION_GENERIC_ACCESSORY", "d8/dcb/classHPLFPSDK_1_1Types.html#a8f558c300b1b53d137cd0c145ab228f8ad21e21473140e8132986d2bc1cae0971", null ],
      [ "MEDIADESTINATION_SAME", "d8/dcb/classHPLFPSDK_1_1Types.html#a8f558c300b1b53d137cd0c145ab228f8a66bf2489e20e9ebc377f33642e1c83b5", null ]
    ] ],
    [ "MediaSource", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0", [
      [ "MEDIASOURCE_MANUAL_FEED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0af442b07ea10ca6aac42ddf23cb671cb1", null ],
      [ "MEDIASOURCE_ROLL1", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0a51c6699f30d8dcf60f87a10093ffaad5", null ],
      [ "MEDIASOURCE_ROLL2", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0a8ea15f25497ab97e5f034023c5271155", null ],
      [ "MEDIASOURCE_ROLL3", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0a24ddd832f79ba3dbfc4d769205ee3df5", null ],
      [ "MEDIASOURCE_ROLL4", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0a380e693292c6d83a365f3d5b4b64b3d8", null ],
      [ "MEDIASOURCE_ROLL5", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0aca926b422d9c85f2b157a696755f40d1", null ],
      [ "MEDIASOURCE_ROLL6", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0a9ee6c95e7c60d48a585ba91b95ae449d", null ],
      [ "MEDIASOURCE_ROLL", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0acd649ce9ac6a546458593a991d15f745", null ],
      [ "MEDIASOURCE_AUTO", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0abc3eb38b32ded21cbaaa7891827bd57a", null ],
      [ "MEDIASOURCE_SAME", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0ac0948bce771f398fb2379246b6873024", null ],
      [ "MEDIASOURCE_TRAY", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0a9c4904f38de4d11dc42ffe3e5cf227a5", null ],
      [ "MEDIASOURCE_TRAY1", "d8/dcb/classHPLFPSDK_1_1Types.html#ac67a0d3e0995f0535b0793557f4b3da0a62e65ab87edda7676b6613ffa8093f4c", null ]
    ] ],
    [ "Overcoat", "d8/dcb/classHPLFPSDK_1_1Types.html#aa1b1e5608ae4f8dacacbca86d4be3a6b", [
      [ "OVERCOAT_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#aa1b1e5608ae4f8dacacbca86d4be3a6ba48858da9ac29e2120ca034dc4c1e3c20", null ],
      [ "OVERCOAT_ON", "d8/dcb/classHPLFPSDK_1_1Types.html#aa1b1e5608ae4f8dacacbca86d4be3a6ba52151b2e016dfe53ead6c9a8a10c1665", null ]
    ] ],
    [ "PrintArea", "d8/dcb/classHPLFPSDK_1_1Types.html#a198469b911a850c3734c3475fb66aa36", [
      [ "PRINTAREA_FULL_SIZE", "d8/dcb/classHPLFPSDK_1_1Types.html#a198469b911a850c3734c3475fb66aa36a60b5ab3cd9724ff3c70b2565755150ef", null ],
      [ "PRINTAREA_INKED_AREA", "d8/dcb/classHPLFPSDK_1_1Types.html#a198469b911a850c3734c3475fb66aa36acc60f2ac799e7a828d5156ad7e13e4fc", null ]
    ] ],
    [ "PrinterFamily", "d8/dcb/classHPLFPSDK_1_1Types.html#a07c901a9f1c77fd9608431b42f9a8835", [
      [ "PRINTER_FAMILY_UNKNOWN", "d8/dcb/classHPLFPSDK_1_1Types.html#a07c901a9f1c77fd9608431b42f9a8835a25f1ccbd6b764dc66a09eb41b90c2a0a", null ],
      [ "PRINTER_FAMILY_DESIGNJET", "d8/dcb/classHPLFPSDK_1_1Types.html#a07c901a9f1c77fd9608431b42f9a8835afa785cf12a346675cd8a970b1b3d9b41", null ],
      [ "PRINTER_FAMILY_LATEX", "d8/dcb/classHPLFPSDK_1_1Types.html#a07c901a9f1c77fd9608431b42f9a8835a3bb297a1985e2656251744b8a145d71a", null ]
    ] ],
    [ "PrintingOrder", "d8/dcb/classHPLFPSDK_1_1Types.html#a923b398b18dabb4881b397f708fa3872", [
      [ "PRINTINGORDER_FIRST_PAGE_ON_TOP", "d8/dcb/classHPLFPSDK_1_1Types.html#a923b398b18dabb4881b397f708fa3872a9f133f7ed04b1547efaf89d300d779e5", null ],
      [ "PRINTINGORDER_LAST_PAGE_ON_TOP", "d8/dcb/classHPLFPSDK_1_1Types.html#a923b398b18dabb4881b397f708fa3872aabfcf3b535fcfd50205cf5bce512ac8e", null ],
      [ "PRINTINGORDER_DIRECT", "d8/dcb/classHPLFPSDK_1_1Types.html#a923b398b18dabb4881b397f708fa3872ae3f4ad507a1580a31829858330936185", null ],
      [ "PRINTINGORDER_REVERSE", "d8/dcb/classHPLFPSDK_1_1Types.html#a923b398b18dabb4881b397f708fa3872ac92e1b32f24e4511f830c9c0ef48f4f9", null ]
    ] ],
    [ "PrintQuality", "d8/dcb/classHPLFPSDK_1_1Types.html#ad552a4e641b0051e91022b08521c8ebf", [
      [ "PRINTQUALITY_FAST", "d8/dcb/classHPLFPSDK_1_1Types.html#ad552a4e641b0051e91022b08521c8ebfa99d2318f39e4ab99753ee6cfce4fce1a", null ],
      [ "PRINTQUALITY_NORMAL", "d8/dcb/classHPLFPSDK_1_1Types.html#ad552a4e641b0051e91022b08521c8ebfabd1613d37d5b169bca5f733caf7e205f", null ],
      [ "PRINTQUALITY_BEST", "d8/dcb/classHPLFPSDK_1_1Types.html#ad552a4e641b0051e91022b08521c8ebfaf6c313714fb914a0cb8c0de24dd0eace", null ],
      [ "PRINTQUALITY_MARVELOUS", "d8/dcb/classHPLFPSDK_1_1Types.html#ad552a4e641b0051e91022b08521c8ebfa74e7b28f8e5e4adaf11c7e389a95e500", null ]
    ] ],
    [ "RasterFormat", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81", [
      [ "INVALID", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81abaaf51125ce45bd7d9626e30c7f2c7a9", null ],
      [ "xRGB", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81a5104fe04d579067edbe3917bcdddbe8b", null ],
      [ "xBGR", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81adeddb709ba5e3eba2f495651ba112266", null ],
      [ "RGBx", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81a99d4224f1b3244e3f004c3dc01531c7a", null ],
      [ "KCMY", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81a8adfe4c5aa6bd750f0e3f0e3e9f159f2", null ],
      [ "KYMC", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81a65ad04ac8462fdf9befd2c0a71d36ff5", null ],
      [ "CMYK", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81a8abc1cbb90d53b63b12af13dc887cdf2", null ],
      [ "RGB", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81a30d95fa38be01ef0aa077d611e31b718", null ],
      [ "PLANAR", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81aeda5a9c25eb875c02658cdb8e4963190", null ],
      [ "PLANAR_HT", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81afacff8f247c8df4ce2a13c62ccebe55c", null ],
      [ "BGR", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81a0f9d720e1dedb25f083306a15c295820", null ],
      [ "BGRx", "d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81a14682da99cee04643b7a9aad44b92d5c", null ]
    ] ],
    [ "RasterLibState", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2c", [
      [ "RASTER_LIB_STATE_WAITING_FOR_JOB_BEGIN", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2ca333d8604baed625587f99d0dec875d38", null ],
      [ "RASTER_LIB_STATE_WAITING_FOR_PAGE_BEGIN", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2ca293842d9e5de9aa614f4cea5c09dbb1c", null ],
      [ "RASTER_LIB_STATE_WAITING_FOR_FIRST_RASTER_START", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2ca639f0046f42fa450932918e1c74ac308", null ],
      [ "RASTER_LIB_STATE_WAITING_FOR_RASTER_START", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2caeae4b6452d4b8cac2167fde8e30737da", null ],
      [ "RASTER_LIB_STATE_WAITING_FOR_RASTER", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2ca5332f5508a33eb19e470dd209c9476d8", null ],
      [ "RASTER_LIB_STATE_WAITING_FOR_RASTER_END", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2ca0249ad47823388b0e58bd9b517f01f2b", null ],
      [ "RASTER_LIB_STATE_WAITING_FOR_PAGE_END", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2cab5c8fe70f853defb331dea361ab3a11e", null ],
      [ "RASTER_LIB_STATE_WAITING_FOR_JOB_END", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2ca1c2443f9d26ce912e19e8ca1412472c4", null ],
      [ "RASTER_LIB_STATE_WAITING_FOR_DELETE", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2cac52a0f22054070ba479f1a5c694fec28", null ],
      [ "RASTER_LIB_STATE_ERROR", "d8/dcb/classHPLFPSDK_1_1Types.html#ad833eb11874f8f82bbc5c8aa94835a2cabe24eff14c57acb2a687f2a0fb6acb38", null ]
    ] ],
    [ "RenderingResolution", "d8/dcb/classHPLFPSDK_1_1Types.html#a2a70e465abedd1007ceb616e66e0b085", [
      [ "RENDERINGRESOLUTION_RES_72", "d8/dcb/classHPLFPSDK_1_1Types.html#a2a70e465abedd1007ceb616e66e0b085a35ba93a534208de116ea712385882f27", null ],
      [ "RENDERINGRESOLUTION_RES_150", "d8/dcb/classHPLFPSDK_1_1Types.html#a2a70e465abedd1007ceb616e66e0b085aff701c0dd54a87760c1640c2a8c7edd6", null ],
      [ "RENDERINGRESOLUTION_RES_200", "d8/dcb/classHPLFPSDK_1_1Types.html#a2a70e465abedd1007ceb616e66e0b085a22533deb78090068861e4117d9843de8", null ],
      [ "RENDERINGRESOLUTION_RES_300", "d8/dcb/classHPLFPSDK_1_1Types.html#a2a70e465abedd1007ceb616e66e0b085a22cc3837f8649b901b4ddf2233c652a7", null ],
      [ "RENDERINGRESOLUTION_RES_400", "d8/dcb/classHPLFPSDK_1_1Types.html#a2a70e465abedd1007ceb616e66e0b085aa0cee5dfaed3cc2e82d4ac06230ce50e", null ],
      [ "RENDERINGRESOLUTION_RES_600", "d8/dcb/classHPLFPSDK_1_1Types.html#a2a70e465abedd1007ceb616e66e0b085a1995ac581d56fb24161ef3300344e1f6", null ],
      [ "RENDERINGRESOLUTION_RES_1200", "d8/dcb/classHPLFPSDK_1_1Types.html#a2a70e465abedd1007ceb616e66e0b085a258e534d77571c2e9c623fc5e37e7e6e", null ]
    ] ],
    [ "RenderIntent", "d8/dcb/classHPLFPSDK_1_1Types.html#aae4272240997cfe37e90b31681d9ef0b", [
      [ "RENDERINTENT_PERCEPTUAL", "d8/dcb/classHPLFPSDK_1_1Types.html#aae4272240997cfe37e90b31681d9ef0ba8cad9d04ce415ff290959f26debb043f", null ],
      [ "RENDERINTENT_RELATIVE_COLORIMETRIC", "d8/dcb/classHPLFPSDK_1_1Types.html#aae4272240997cfe37e90b31681d9ef0babebb1a30fde78731ac64fe35ce8b594a", null ],
      [ "RENDERINTENT_SATURATION", "d8/dcb/classHPLFPSDK_1_1Types.html#aae4272240997cfe37e90b31681d9ef0ba5eb8c83715dd6c02644c6e97dd60a23b", null ],
      [ "RENDERINTENT_ABSOLUTE_COLORIMETRIC", "d8/dcb/classHPLFPSDK_1_1Types.html#aae4272240997cfe37e90b31681d9ef0bafbec21c0f618d139ccd4582dcb291a82", null ]
    ] ],
    [ "RenderMode", "d8/dcb/classHPLFPSDK_1_1Types.html#a89709b49d04fa966b5a54dd14dc3c1a3", [
      [ "RENDERMODE_COLOR", "d8/dcb/classHPLFPSDK_1_1Types.html#a89709b49d04fa966b5a54dd14dc3c1a3abd9becd24ccb7a4533fc1bfa36d36b6f", null ],
      [ "RENDERMODE_GRAYSCALE", "d8/dcb/classHPLFPSDK_1_1Types.html#a89709b49d04fa966b5a54dd14dc3c1a3a8df659a05d200494c51dc38d1db98fc7", null ],
      [ "RENDERMODE_TRUEGRAYSCALE", "d8/dcb/classHPLFPSDK_1_1Types.html#a89709b49d04fa966b5a54dd14dc3c1a3a3fc0ad03c81f0668a5281ff3293478c3", null ],
      [ "RENDERMODE_BLACKANDWHITE", "d8/dcb/classHPLFPSDK_1_1Types.html#a89709b49d04fa966b5a54dd14dc3c1a3a1f35613967c11ee9e53f994b4c3aeab9", null ]
    ] ],
    [ "Result", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6bec", [
      [ "RESULT_OK", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca1aa50160d362d2595076aab39a9fd060", null ],
      [ "RESULT_ERROR_INVALID_PARAMETER", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca4e466daff64e7d2b73c5e8857fe78d88", null ],
      [ "RESULT_ERROR_UNSUPPORTED_RASTER_FMT", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca27a1a62210a6a16487be2ef20151af3f", null ],
      [ "RESULT_ERROR_INVALID_USAGE_SEQUENCE", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca76af82e07067c2a5cfec31ed63257213", null ],
      [ "RESULT_ERROR_COMPRESSOR", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca0b9abd3fced2c6502da3793fa699b1fb", null ],
      [ "RESULT_ERROR_MEMORY", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca5e11b2ae01cab750365a9dc0e488abc2", null ],
      [ "RESULT_ERROR_INTERNAL", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca7385ce1669e6b7b6dcdbafa8f76f1410", null ],
      [ "RESULT_ERROR_MEDIUM_KEY_NOT_VALID", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaac34bedebab90947a33f46d3afb445ca", null ],
      [ "RESULT_ERROR_PROFILE_NOT_EXIST", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca3b99c78b3665f32a55d1f6d79b88c3c4", null ],
      [ "RESULT_ERROR_MEDIUM_CANNOT_BE_DELETED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca311b00ade691c263cf4240d7a24a125d", null ],
      [ "RESULT_ERROR_MEDIUM_NOT_EXIST", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaa4721cb7a34254fd28d382cb87af81ef", null ],
      [ "RESULT_ERROR_MEDIUM_ALREADY_EXIST", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becae9f52b8b6ba5a65de22c81b0d1eb890e", null ],
      [ "RESULT_ERROR_NO_ROOM_FOR_MORE_MEDIA", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca15291bc6a0041fa6bfad0c1a82044214", null ],
      [ "RESULT_ERROR_MEDIUM_CANNOT_BE_CLONED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca2376049565185c79d5ac0b3671e21f37", null ],
      [ "RESULT_ERROR_PROFILE_CANNOT_BE_DELETED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca9547f757434f7d26d6b8dadebcbfabdf", null ],
      [ "RESULT_ERROR_MEDIUM_MISSING_NAME", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaa6d9a510d81564259def0352a5ad7a00", null ],
      [ "RESULT_ERROR_INCOMPLETE_COND_SPEC", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca76d73a1c629677a1a8234104e5f2cf1b", null ],
      [ "RESULT_ERROR_INCOMPLETE_PRINTMODE_SPEC", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becac553a7c68d83d898367a24c59699344b", null ],
      [ "RESULT_ERROR_SPECIFIED_FILE_DOES_NOT_EXIST", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca632534dd52ba6283de69226773b1d57b", null ],
      [ "RESULT_ERROR_UPDATING_SETTINGS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becab0d4726d300b3141f1274fb9059524e7", null ],
      [ "RESULT_ERROR_MEDIUM_IS_REQUIRED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca3a29c66bb50b35c3b3ca728e717753ac", null ],
      [ "RESULT_ERROR_TOO_MANY_PROPERTIES", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca255d15dd6d4d743b1a6b7f44699eb3dc", null ],
      [ "RESULT_ERROR_SUPPORTED_PM_FILE_NOT_FOUND", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca964c7420442102e5720885984c539364", null ],
      [ "RESULT_ERROR_MEDIUM_CANNOT_BE_MODIFIED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca964a0c389e904075ee819349a6aecf66", null ],
      [ "RESULT_ERROR_NO_ROOM_FOR_MORE_MODES", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca8cba5026a381d2b3cd38fc132241d506", null ],
      [ "RESULT_ERROR_MODE_DOESNT_EXIST", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca857141e19212902842d399f720003276", null ],
      [ "RESULT_ERROR_MODE_ALREADY_EXISTS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca60b245e8fedf7f28fa4698e2ed3ac633", null ],
      [ "RESULT_ERROR_MODE_CANNOT_BE_DELETED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becafc9b69a1564076e11301df0fc89bc2be", null ],
      [ "RESULT_ERROR_CATEGORY_DOESNT_EXIST", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca522a17cf499d4174131f695c97cadebb", null ],
      [ "RESULT_ERROR_PARAM_OUT_OF_RANGE", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca4b0c6c05dd0e45e52419f5d09b6e35f4", null ],
      [ "RESULT_ERROR_MEDIUM_INSTALLING", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca3d12a02b8ba6b5abb31c5178a2b369db", null ],
      [ "RESULT_ERROR_MEDIUM_PROPERTIES_NOT_FOUND", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaffd653f0a16370e7f6764c879060d628", null ],
      [ "RESULT_ERROR_PAPER_MODE_NOT_DEFINED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becac8116fafe289031dc8ab1f1b4dc74f5a", null ],
      [ "RESULT_ERROR_MEDIUM_KEY_NOT_DEFINED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca038239d952699ec4fb9322dda4feb09e", null ],
      [ "RESULT_ERROR_XML_INPUT_DATA_TOO_BIG", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca757c5a77a2fcbf95307fd0498e5857c3", null ],
      [ "RESULT_ERROR_XML_INPUT_DATA_MALFORMED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca719bc229be80d644e4406b75d4ed5098", null ],
      [ "RESULT_ERROR_XML_INPUT_DATA_EMPTY", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca38551fea26ec67b135349e5326dc5f8a", null ],
      [ "RESULT_ERROR_XML_INPUT_DATA_INVALID", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becab5675cd71ffd951961225cd364c34154", null ],
      [ "RESULT_ERROR_CALIBRATION_TYPE_EMPTY", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca637ce7590ebf5be3e50b58756df69feb", null ],
      [ "RESULT_ERROR_CALIBRATION_TYPE_INVALID", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca1fcabc90977b44f848b6a35409786e19", null ],
      [ "RESULT_ERROR_EMPTY_RESPONSE", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca55a4b8e233e443ec9ec32145bb5acb14", null ],
      [ "RESULT_ERROR_NO_MEDIUM_LOADED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaf81acf7781bc4d3ce996ef07d52ad1ba", null ],
      [ "RESULT_ERROR_ELEMENT_NOT_FOUND", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becab51cbbb77c70ab0ff4f0c7233ced7dc7", null ],
      [ "RESULT_ERROR_INVALID_MEDIUM", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaf17ddba0eba62dfe1d4aca0f7c9a9cd7", null ],
      [ "RESULT_ERROR_MEDIUM_MISMATCH", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca83db084db3c6642088a119c9ff526693", null ],
      [ "RESULT_ERROR_NO_EFFECT", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becae2522ef6863e9d2cc3e9470ac6b0659e", null ],
      [ "RESULT_ERROR_PRINTER_BUSY", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca4504c5ba15438e92b2b84979f9bddda8", null ],
      [ "RESULT_ERROR_MEDIUM_NOT_DEFINED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca7a429c67c9a114d1890838e2cd6b2d94", null ],
      [ "RESULT_ERROR_MEDIUM_CANNOT_BE_RESET", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca9f237561f9b0314e52d5da7021b4cb85", null ],
      [ "RESULT_ERROR_ALREADY_IN_FACTORY_SETTINGS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaf4b3b313cd358fc3bf79d1e2f1b7c96e", null ],
      [ "RESULT_ERROR_MANUAL_DELETION_NEEDED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca3a59b05fc5cf4a08534a44bbf6de5018", null ],
      [ "RESULT_ERROR_MEDIUM_IDENTIFIER_PROPERTIES_NOT_SET", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca2fa4a1a5766d339a09ede858aaed7571", null ],
      [ "RESULT_ERROR_INVALID_RESPONSE", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca20e46bbede0621a0201be1182a1d8a71", null ],
      [ "RESULT_ERROR_CONNECTION", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca67a8aad3f699f67f43c0a3b4915f434f", null ],
      [ "RESULT_ERROR", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca4f63c0ff27f171c588d2015c7287c73b", null ],
      [ "RESULT_ERROR_DEVICE_ALREADY_EXISTS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca087959166252ff3e08e490607d53961c", null ],
      [ "RESULT_ERROR_FILE_NOT_FOUND", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca0c210e8ada2ec85659f88e496d0b4dcc", null ],
      [ "RESULT_NOT_SUPPORTED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca7bccfca70ff580eb0aa5885aad7748ae", null ],
      [ "RESULT_ERROR_NOT_NETWORK_AVAILABLE", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca8b3502b39166be7217d92e0631bcc54a", null ],
      [ "RESULT_WARNING_DEVICE_NOT_CONNECTED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca659651d783bca8f65c28ffbecc3999d7", null ],
      [ "RESULT_ERROR_SETTING_MANDATORY_NOT_SET", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca6318f7e3d329c58cb9675c491c9fb43a", null ],
      [ "RESULT_ERROR_IN_MARGINS_SETTINGS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becae081d1426b94e25dd671f9af5c213fdb", null ],
      [ "RESULT_ERROR_PRINTER_MODEL_UNKNOWN", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca63085cff09a2d1f48175dea75408b7b8", null ],
      [ "RESULT_ERROR_MEDIA_SOURCE_NOT_SUPPORTED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaa768c15e2735b1a3069e34fc333cefe2", null ],
      [ "RESULT_ERROR_FOLDER_SETTINGS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca314236d6a224f98f11f29b6e05b3609c", null ],
      [ "RESULT_ERROR_LIBRARY_NOT_INITIALIZED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca86c6515b766921dfa8b00fe88f77c7f8", null ],
      [ "RESULT_PAGE_SETTINGS_NULL", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becad5b1e466ad5819502e36b7879e6f1d07", null ],
      [ "RESULT_ERROR_CHART_DOES_NOT_FIT_AREA_TOO_SMALL", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca9608c47923280d613384f91475776fd5", null ],
      [ "RESULT_ERROR_CHART_DOES_NOT_FIT_NO_SPACE_FOR_ALIGNMENT_MARKS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becac58a9a3e67f310848cf4571f7946f82b", null ],
      [ "RESULT_ERROR_CHART_DOES_NOT_FIT_NO_SPACE_FOR_PATCHES", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaafc10c4b5603066f190f322cd4227fd0", null ],
      [ "RESULT_ERROR_CHART_DOES_NOT_FIT_NO_SPACE_FOR_COLUMNS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaf6ca5615c34c2f95a14ada374f7739e8", null ],
      [ "RESULT_ERROR_CHART_DOES_NOT_FIT_NO_SPACE_FOR_ROWS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becaba880b79ebebd8417bf9f007b2920049", null ],
      [ "RESULT_ERROR_CHART_INVALID_GEOMETRY", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca97031a63ec6b07c81fff79489086c7b5", null ],
      [ "RESULT_ERROR_CHART_OVERLAPPED_REGIONS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca1f99c1aa06846aa80cdce0db2e22e075", null ],
      [ "RESULT_ERROR_CHART_INVALID_ALIGNMENT_MARK", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca3630ed502a767d7cd539ee9d96ffddbf", null ],
      [ "RESULT_ERROR_CHART_OVERLAPPED_LEFT_ALIGNMENT_MARK", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca18f93371a7817972ae979089c4514d81", null ],
      [ "RESULT_ERROR_CHART_OVERLAPPED_RIGHT_ALIGNMENT_MARK", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becae5f18c9ad43954875ac3d48052bc0306", null ],
      [ "RESULT_ERROR_CHART_INCOMPATIBLE_ALIGNMENT_MARK", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca068a1adbda06bfb5e4d44b264f551e79", null ],
      [ "RESULT_ERROR_CHART_LAYOUT_OVERFLOW", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca7c7ea66c15f098e557481a7b23f7d883", null ],
      [ "RESULT_ERROR_CHART_UNKNOWN_COLOR_SPACE", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca34be923a7ac71aea0f2a59c8bf89bc0b", null ],
      [ "RESULT_ERROR_CHART_INCOMPATIBLE_COLOR_DEFINITION", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becae570d5cc7adf48b16a1ba427e218bd8f", null ],
      [ "RESULT_ERROR_TIMEOUT", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca5326c1ee3ad2fe45da4a5af7ae00b20e", null ],
      [ "RESULT_ERROR_NOT_YET_INITIALIZED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca9f6242b0813e1f354050d96f494edbae", null ],
      [ "RESULT_OFFLINE_OPERATION", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca5e745aba39d9be2eaa9b148f24d91a4f", null ],
      [ "RESULT_ERROR_PARAM_SIZE_OUT_OF_RANGE", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca954f6087b93cd6759cfd008e74d6b023", null ],
      [ "RESULT_ERROR_TOO_MANY_ELEMENTS", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6becafaa0a4ba57e7f074d302190070e76d50", null ],
      [ "RESULT_ERROR_UNAUTHORIZED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca7f141b66e9fee3bed382c78610624038", null ],
      [ "RESULT_ERROR_SERVICE_UNAVAILABLE", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca1fbe7158b5e1bf533c295b2fa0e703cc", null ],
      [ "RESULT_ERROR_SIDE_B_NOT_SUPPORTED", "d8/dcb/classHPLFPSDK_1_1Types.html#ac21941b2aefdec8433f0c3f5f45a6beca5d17dc2f14d5bf0d9cd80b980debcbf1", null ]
    ] ],
    [ "RetMode", "d8/dcb/classHPLFPSDK_1_1Types.html#abf0147f817b1d2d44427e6ce483227f2", [
      [ "RETMODE_ON", "d8/dcb/classHPLFPSDK_1_1Types.html#abf0147f817b1d2d44427e6ce483227f2a8d73a8321229c22fda7b46ad19a0dc4d", null ],
      [ "RETMODE_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#abf0147f817b1d2d44427e6ce483227f2ae12d82c5537b2125993ce04e06130067", null ]
    ] ],
    [ "RollSwitchPolicy", "d8/dcb/classHPLFPSDK_1_1Types.html#a3d3764efb0d501711550c5b0148beff0", [
      [ "ROLLSWITCHPOLICY_MAXIMIZE_PRODUCTIVITY", "d8/dcb/classHPLFPSDK_1_1Types.html#a3d3764efb0d501711550c5b0148beff0aeb410e6d98dbb506b7c99c494bd84b7a", null ],
      [ "ROLLSWITCHPOLICY_LESS_REMAINING_PAPER", "d8/dcb/classHPLFPSDK_1_1Types.html#a3d3764efb0d501711550c5b0148beff0a95bec277579558c14ac62153f6d007db", null ],
      [ "ROLLSWITCHPOLICY_SAVE_PAPER", "d8/dcb/classHPLFPSDK_1_1Types.html#a3d3764efb0d501711550c5b0148beff0aff39fa1d495b159024a550e8249ec4bf", null ]
    ] ],
    [ "ScanBinaryRendering", "d8/dcb/classHPLFPSDK_1_1Types.html#ab2ab74400a0dc30981aa31c61a125409", [
      [ "SCAN_BINARY_RENDERING_HALFTONE", "d8/dcb/classHPLFPSDK_1_1Types.html#ab2ab74400a0dc30981aa31c61a125409a6c65e2fa71ac2579390f80031c343d5e", null ],
      [ "SCAN_BINARY_RENDERING_THRESHOLD", "d8/dcb/classHPLFPSDK_1_1Types.html#ab2ab74400a0dc30981aa31c61a125409ab80d5dffee6c89a659a6a8ff5b2f3323", null ],
      [ "SCAN_BINARY_RENDERING_ERROR_DIFUSION", "d8/dcb/classHPLFPSDK_1_1Types.html#ab2ab74400a0dc30981aa31c61a125409a5b7f00bc25ef133a573264617d45fb95", null ]
    ] ],
    [ "ScanCcdChannel", "d8/dcb/classHPLFPSDK_1_1Types.html#a0c5ad12b734e541fc8278238eb891093", [
      [ "SCAN_CCD_NTSC", "d8/dcb/classHPLFPSDK_1_1Types.html#a0c5ad12b734e541fc8278238eb891093ad32f047906b3201e9ceef0ee052963a5", null ],
      [ "SCAN_CCD_GRAY", "d8/dcb/classHPLFPSDK_1_1Types.html#a0c5ad12b734e541fc8278238eb891093a1860386d14bbfd1c81f551b5c2035d43", null ],
      [ "SCAN_CCD_GRAY_EMULATED", "d8/dcb/classHPLFPSDK_1_1Types.html#a0c5ad12b734e541fc8278238eb891093a0e2c09e6e86353186e5a6e9ef0c5c2b1", null ],
      [ "SCAN_CCD_RED", "d8/dcb/classHPLFPSDK_1_1Types.html#a0c5ad12b734e541fc8278238eb891093a14410adc15707153db3258cb1d5bc785", null ],
      [ "SCAN_CCD_GREEN", "d8/dcb/classHPLFPSDK_1_1Types.html#a0c5ad12b734e541fc8278238eb891093a6795a073907cc1dde57fcf89bd5a9c68", null ],
      [ "SCAN_CCD_BLUE", "d8/dcb/classHPLFPSDK_1_1Types.html#a0c5ad12b734e541fc8278238eb891093a0995a48e02ccaa0d63f31d539467baed", null ]
    ] ],
    [ "ScanColorAutodetectionMode", "d8/dcb/classHPLFPSDK_1_1Types.html#a1a3903e8d1fca2affd5e571cb898a139", [
      [ "SCAN_COLOR_AUTODETECTION_DETECT_ONLY", "d8/dcb/classHPLFPSDK_1_1Types.html#a1a3903e8d1fca2affd5e571cb898a139aa590dc382b0fafc76d42fbaf7312cf73", null ],
      [ "SCAN_COLOR_AUTODETECTION_TREAT_NON_COLOR_AS_BLACK_AND_WHITE_1", "d8/dcb/classHPLFPSDK_1_1Types.html#a1a3903e8d1fca2affd5e571cb898a139abebe5773fd2a1955fc730bade9a99b4b", null ],
      [ "SCAN_COLOR_AUTODETECTION_TREAT_NON_COLOR_AS_GRAYSCALE_8", "d8/dcb/classHPLFPSDK_1_1Types.html#a1a3903e8d1fca2affd5e571cb898a139a1cc479d60ac21dd698dd491261f2011a", null ]
    ] ],
    [ "ScanColorMode", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314", [
      [ "SCAN_COLOR_MODE_BLACK_AND_WHITE_1", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314a37f056ba08f9fac9cd57d4e56f81ebea", null ],
      [ "SCAN_COLOR_MODE_GRAYSCALE_4", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314a9f2d7c93222f2c23ce287e328c40553f", null ],
      [ "SCAN_COLOR_MODE_GRAYSCALE_8", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314a5fc6d7b82cb0b884c9ce732a81085cd7", null ],
      [ "SCAN_COLOR_MODE_GRAYSCALE_16", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314aa427432c841fd0cd3eae3057ba15874b", null ],
      [ "SCAN_COLOR_MODE_RGB_24", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314a2f7aa4076995815672fc1029d426fd93", null ],
      [ "SCAN_COLOR_MODE_RGB_48", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314aac27f4c8d4c7d02b99ccac46a6150532", null ],
      [ "SCAN_COLOR_MODE_RGBA_32", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314a9bf667031ba1def136c9d003aef57710", null ],
      [ "SCAN_COLOR_MODE_RGBA_64", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314acdd4fe4dd6ceb0038a8c8db458761270", null ],
      [ "SCAN_COLOR_MODE_CMYK_32", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314ab0a5819c79928cbebce9fd5c275dd803", null ],
      [ "SCAN_COLOR_MODE_AUTO", "d8/dcb/classHPLFPSDK_1_1Types.html#ada271da3dd946fa8defb41308cb04314aaf0575848f87a0b98ecda53e23515c43", null ]
    ] ],
    [ "ScanColorSpace", "d8/dcb/classHPLFPSDK_1_1Types.html#af7150bf971be4557828367c6dcd002ec", [
      [ "SCAN_COLOR_SPACE_RGB", "d8/dcb/classHPLFPSDK_1_1Types.html#af7150bf971be4557828367c6dcd002ecad1722148176d48b1d424960b06c676ef", null ],
      [ "SCAN_COLOR_SPACE_SRGB", "d8/dcb/classHPLFPSDK_1_1Types.html#af7150bf971be4557828367c6dcd002ecaea0b5403ea010b612a657637a31f16e5", null ],
      [ "SCAN_COLOR_SPACE_SCRGB", "d8/dcb/classHPLFPSDK_1_1Types.html#af7150bf971be4557828367c6dcd002eca86d0defe60f05300a1d1e90026904b84", null ],
      [ "SCAN_COLOR_SPACE_CMY", "d8/dcb/classHPLFPSDK_1_1Types.html#af7150bf971be4557828367c6dcd002eca2d07e9a26b69b6e23173c5a1d081732b", null ],
      [ "SCAN_COLOR_SPACE_CMYK", "d8/dcb/classHPLFPSDK_1_1Types.html#af7150bf971be4557828367c6dcd002eca9afd845fb06fec54c1e5820e65fe73af", null ],
      [ "SCAN_COLOR_SPACE_YCC", "d8/dcb/classHPLFPSDK_1_1Types.html#af7150bf971be4557828367c6dcd002ecac2f9e67473974550099c46ab46c01736", null ]
    ] ],
    [ "ScanContentType", "d8/dcb/classHPLFPSDK_1_1Types.html#a6970c2d01e0a97f4d93dd1d0bd205ecf", [
      [ "SCAN_CONTENT_AUTO", "d8/dcb/classHPLFPSDK_1_1Types.html#a6970c2d01e0a97f4d93dd1d0bd205ecfaca437ed9168ea708507d5afa4b5f8a33", null ],
      [ "SCAN_CONTENT_TEXT", "d8/dcb/classHPLFPSDK_1_1Types.html#a6970c2d01e0a97f4d93dd1d0bd205ecfa19c0282aa2613b568e1502fe7f6b4aea", null ],
      [ "SCAN_CONTENT_PHOTO", "d8/dcb/classHPLFPSDK_1_1Types.html#a6970c2d01e0a97f4d93dd1d0bd205ecfac83de40165f01dd9e094a0e6628d617b", null ],
      [ "SCAN_CONTENT_TEXT_AND_PHOTO", "d8/dcb/classHPLFPSDK_1_1Types.html#a6970c2d01e0a97f4d93dd1d0bd205ecfa96340fd3bc44829aad1856e503520292", null ],
      [ "SCAN_CONTENT_LINE_ART", "d8/dcb/classHPLFPSDK_1_1Types.html#a6970c2d01e0a97f4d93dd1d0bd205ecfaa3b22dfaddc886d42f205e6597d5daeb", null ],
      [ "SCAN_CONTENT_MAGAZINE", "d8/dcb/classHPLFPSDK_1_1Types.html#a6970c2d01e0a97f4d93dd1d0bd205ecfa09d0349c46987e8c12f52f46ab379abd", null ],
      [ "SCAN_CONTENT_HALFTONE", "d8/dcb/classHPLFPSDK_1_1Types.html#a6970c2d01e0a97f4d93dd1d0bd205ecfad98f2001e1efce7d962a106110328b82", null ]
    ] ],
    [ "ScanDocumentFormat", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6a", [
      [ "SCAN_FORMAT_APPLICATION_UNKNOWN", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aa12e26a1c165f3dc2016336e23ef075f0", null ],
      [ "SCAN_FORMAT_APPLICATION_OCTETSTREAM", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aa51b85fa4ac7acf8d85c5bae1931f813f", null ],
      [ "SCAN_FORMAT_APPLICATION_PDF", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aacc7786eb04f93c0d42049914aa50ac07", null ],
      [ "SCAN_FORMAT_APPLICATION_POSTSCRIPT", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aa6776d228fbb975f9c490dafd4cd27c24", null ],
      [ "SCAN_FORMAT_APPLICATION_VND_PWG_XHTML_PRINT_XML", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aaa1ab4ec9bf68b4f3c3d0e6cfa8ca3b3e", null ],
      [ "SCAN_FORMAT_APPLICATION_VND_HP_PCL", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aa3c8922babab46e37fa4e4b51634c9b07", null ],
      [ "SCAN_FORMAT_APPLICATION_VND_HP_CLOUD_EPRINT_SCAN_GSR_1_0_ZLIB", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aa8af75560f756b5a5eb481261e8b26e7f", null ],
      [ "SCAN_FORMAT_IMAGE_G3FAX", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aa08fcf8b6ef7aeb7f2a69c222d9cf3f47", null ],
      [ "SCAN_FORMAT_IMAGE_JPEG", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aa140d87365d1d93faf47a6351c5eff1a4", null ],
      [ "SCAN_FORMAT_IMAGE_PNG", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aacf3c738529e9f55150213a74efd691c5", null ],
      [ "SCAN_FORMAT_IMAGE_TIFF", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aab779578f3a4ddb4b48f5e820d5be087b", null ],
      [ "SCAN_FORMAT_IMAGE_TIFF_FX", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aa94a9c10f00457247d08a25d08458861b", null ],
      [ "SCAN_FORMAT_TEXT_HTML", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aae484148b4d0781af5a48f01134b16230", null ],
      [ "SCAN_FORMAT_TEXT_PLAIN", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aafe916fe2ff61122a9898c9f1cb86ed65", null ],
      [ "SCAN_FORMAT_TEXT_PLAIN_CHARSET_ISO_8859_1", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aa49755f0cee8abb11c8c6a29039e080e0", null ],
      [ "SCAN_FORMAT_TEXT_PLAIN_CHARSET_US_ASCII", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aaac4322e03f9ac02ab61c5f42f3c3c745", null ],
      [ "SCAN_FORMAT_TEXT_PLAIN_CHARSET_UTF_8", "d8/dcb/classHPLFPSDK_1_1Types.html#ae95a922f8678881eb290000e26c79a6aac25b3a2da8d7f8dc8aa9f4a47379c104", null ]
    ] ],
    [ "ScanFeedDirection", "d8/dcb/classHPLFPSDK_1_1Types.html#a51c89060c24df30c8b4d48d52f159d69", [
      [ "SCAN_FEED_DIRECTION_LONG_EDGE", "d8/dcb/classHPLFPSDK_1_1Types.html#a51c89060c24df30c8b4d48d52f159d69aff3f475d34b443b1c22c31afc189bf26", null ],
      [ "SCAN_FEED_DIRECTION_SHORT_EDGE", "d8/dcb/classHPLFPSDK_1_1Types.html#a51c89060c24df30c8b4d48d52f159d69a6095b8f0142d64effa9c9b17cc92e1e8", null ]
    ] ],
    [ "ScanInputSource", "d8/dcb/classHPLFPSDK_1_1Types.html#a944f3135022b54fb795ae63c3baba319", [
      [ "SCAN_INPUT_PLATEN", "d8/dcb/classHPLFPSDK_1_1Types.html#a944f3135022b54fb795ae63c3baba319a1e314ccb9d51b3fbb8512a3527f7ff2d", null ],
      [ "SCAN_INPUT_FEEDER", "d8/dcb/classHPLFPSDK_1_1Types.html#a944f3135022b54fb795ae63c3baba319a1a2da43db4d2ff59610eea4f84931652", null ]
    ] ],
    [ "ScanIntent", "d8/dcb/classHPLFPSDK_1_1Types.html#a80220a4c8263c7216346523be9e6eef9", [
      [ "SCAN_INTENT_DOCUMENT", "d8/dcb/classHPLFPSDK_1_1Types.html#a80220a4c8263c7216346523be9e6eef9a71c0f419c04f6ebe4d9d9784599917c8", null ],
      [ "SCAN_INTENT_TEXT_AND_GRAPHIC", "d8/dcb/classHPLFPSDK_1_1Types.html#a80220a4c8263c7216346523be9e6eef9a43b1bc6a8672f67ece6a42155b963894", null ],
      [ "SCAN_INTENT_PHOTO", "d8/dcb/classHPLFPSDK_1_1Types.html#a80220a4c8263c7216346523be9e6eef9a1acd7812d5ca0489d5b1b9b8531828c2", null ],
      [ "SCAN_INTENT_PREVIEW", "d8/dcb/classHPLFPSDK_1_1Types.html#a80220a4c8263c7216346523be9e6eef9a1a7550ee1b429e77952aadefc10fcff4", null ],
      [ "SCAN_INTENT_BUSSINESS_CARD", "d8/dcb/classHPLFPSDK_1_1Types.html#a80220a4c8263c7216346523be9e6eef9abb4cf0461db2735555bdbbeb1ab46f7e", null ]
    ] ],
    [ "ScanMediaType", "d8/dcb/classHPLFPSDK_1_1Types.html#ad0e173ee620f76a07ba7d9dff248c5c5", [
      [ "SCAN_MEDIA_TYPE_WHITE", "d8/dcb/classHPLFPSDK_1_1Types.html#ad0e173ee620f76a07ba7d9dff248c5c5a64233757e983c0adf693f218fa505485", null ],
      [ "SCAN_MEDIA_TYPE_PHOTO", "d8/dcb/classHPLFPSDK_1_1Types.html#ad0e173ee620f76a07ba7d9dff248c5c5aa369674deeb506575c61268bc71ba517", null ],
      [ "SCAN_MEDIA_TYPE_BLUEPRINT", "d8/dcb/classHPLFPSDK_1_1Types.html#ad0e173ee620f76a07ba7d9dff248c5c5a9f907b09ac54e4d9fd564d4be2446ffa", null ],
      [ "SCAN_MEDIA_TYPE_OLD_RECICLED", "d8/dcb/classHPLFPSDK_1_1Types.html#ad0e173ee620f76a07ba7d9dff248c5c5a0d3876285be58a2e6bda27914f1c711e", null ],
      [ "SCAN_MEDIA_TYPE_TRANSLUCENT", "d8/dcb/classHPLFPSDK_1_1Types.html#ad0e173ee620f76a07ba7d9dff248c5c5aa7432eee3d3a6bcf66e3d98c69c33ebf", null ]
    ] ],
    [ "SolChartFlags", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60", [
      [ "SOL_CHART_FLAGS_ALIGNMENT_NONE", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60ac4a08522c00e2fe215ec122b78244b16", null ],
      [ "SOL_CHART_FLAGS_ALIGNMENT_LEFT", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a46cad0648b53d713b5fe4553a16068b6", null ],
      [ "SOL_CHART_FLAGS_ALIGNMENT_RIGHT", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60aedde3ba70c5859523970fd0f55c4ec85", null ],
      [ "SOL_CHART_FLAGS_ALIGNMENT_BOTH", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60ab67ae86b0a737279c206b7c585b15291", null ],
      [ "SOL_CHART_FLAGS_ALIGNMENT_MASK", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60ab982975987661c12482b5fcebd2501b4", null ],
      [ "SOL_CHART_FLAGS__RESERVED1__", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60af7b1e8fac679ea4f99816f080763dab2", null ],
      [ "SOL_CHART_FLAGS_LAYOUT_RECTANGULAR", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a58e14308dbdd459403e332852031c58a", null ],
      [ "SOL_CHART_FLAGS_LAYOUT_HEXAGONAL", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a11bce1e6a407bb4f7d4348b1d99a944a", null ],
      [ "SOL_CHART_FLAGS_LAYOUT_MASK", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a7a4cb8f3019bd0d3702bc064ff7c3207", null ],
      [ "SOL_CHART_FLAGS__RESERVED2__", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a183b049c4656761024d6766f4880b8cb", null ],
      [ "SOL_CHART_FLAGS_WARMUP", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a9b0b8f8b4a203d4194c2477a7f903556", null ],
      [ "SOL_CHART_FLAGS_PREHEAT", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a205a0d28ed3dedd5704c852ce11f7426", null ],
      [ "SOL_CHART_FLAGS_HEADER", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a739fcad2987c6747b6779f8324ab419c", null ],
      [ "SOL_CHART_FLAGS_METADATA", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a18174c7b4dafae82873cfd87f7f110a6", null ],
      [ "SOL_CHART_FLAGS_CONTRAST", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60ab41f84f9e4ab7a675db94037ee902249", null ],
      [ "SOL_CHART_FLAGS__RESERVED3__", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a545931ba5e32e29d8e816d23835ac806", null ],
      [ "SOL_CHART_FLAGS_OPTIMIZATION_MASK", "d8/dcb/classHPLFPSDK_1_1Types.html#ada56b3c85d91d7674a1e09e40a418d60a7308d984a5c99e2b414fb0b9f3dba5b0", null ]
    ] ],
    [ "SolChartOptimizationFlags", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567f", [
      [ "SOL_CHART_RENDER_FULL_PAGE", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fac024ed046390404b0803c2e3683ec8dc", null ],
      [ "SOL_CHART_RENDER_PRINTABLE", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa000d6a16df521365b47b36e5448b9458", null ],
      [ "SOL_CHART_RENDER_INKED_AREA", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa65124c520cdf1ed61a204f530673881f", null ],
      [ "SOL_CHART_RENDER_SMART_AREA", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa00b82f9fbc444937636693e08d5ab60a", null ],
      [ "SOL_CHART_RENDER_REGION_MASK", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa6537df2e288b07bcc536aa73c254c7b4", null ],
      [ "SOL_CHART__RESERVED1__", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa056274bacfd3eab76c1d12d90377d209", null ],
      [ "SOL_CHART_GUESS_OPTIMUM_LAYOUT", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fac6934255378d402320aba69f8b40d299", null ],
      [ "SOL_CHART_GUESS_OPTIMUM_ALIGN", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa8050545756e5ea21ae48cb7267beead0", null ],
      [ "SOL_CHART__RESERVED2__", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa945f22f363d51e0b0ea44556d135420b", null ],
      [ "SOL_CHART_MARGINS_NO_MARGINS", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa1208c2173b2e67a3cb9debc4405ec69e", null ],
      [ "SOL_CHART_MARGINS_ONLINE", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fadbf00668e21ddad8e73ee86b1a6e1359", null ],
      [ "SOL_CHART_MARGINS_OFFLINE", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa7f6bfc538faa255ace3ba6f0e8c2292a", null ],
      [ "SOL_CHART_MARGINS_ROLL", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fae2397c07d354a5cee1a377ef192513d9", null ],
      [ "SOL_CHART_MARGINS_MASK", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa777dd637c6e8dcaf8962b3d83d9b7258", null ],
      [ "SOL_CHART__RESERVED3__", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa6049939e4795e7cd7c1857b2efc343f6", null ],
      [ "SOL_CHART_ANCHOR_CENTER", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa33a3d77c6708c15456029a81b24eb28b", null ],
      [ "SOL_CHART_ANCHOR_LEFT", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567faf0e314975cd69b0940986ab466c00cff", null ],
      [ "SOL_CHART_ANCHOR_TOP", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fabbaa67ee410db9d47aaa8385aded1e28", null ],
      [ "SOL_CHART_ANCHOR_RIGHT", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa84984809366aba204b89e128589caa02", null ],
      [ "SOL_CHART_ANCHOR_BOTTOM", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fae26e6aa099add8b01b09be0de86c4e30", null ],
      [ "SOL_CHART_ANCHOR_MASK", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567faa1240fa6eda440558a4450b4390753a1", null ],
      [ "SOL_CHART_HORIZONTAL_ANCHOR_MASK", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa042d730cc894ab6107d1d4128b697d68", null ],
      [ "SOL_CHART_VERTICAL_ANCHOR_MASK", "d8/dcb/classHPLFPSDK_1_1Types.html#a5e344da4760ddd234c4c05a3adff567fa45528dbe9ebb09db6ee52c7ce10cfaaf", null ]
    ] ],
    [ "SolMeasurementType", "d8/dcb/classHPLFPSDK_1_1Types.html#a2c6a29ac1f514900d05c43c34c78a82c", [
      [ "SOL_MEASUREMENT_TYPE_ALL", "d8/dcb/classHPLFPSDK_1_1Types.html#a2c6a29ac1f514900d05c43c34c78a82ca4b391a4cbbe713cb6e6f11f1b2fc7e7c", null ],
      [ "SOL_MEASUREMENT_TYPE_SPECTRAL", "d8/dcb/classHPLFPSDK_1_1Types.html#a2c6a29ac1f514900d05c43c34c78a82cafab6ca1903cd48ebe8e564fbee659d91", null ],
      [ "SOL_MEASUREMENT_TYPE_CIEXYZ", "d8/dcb/classHPLFPSDK_1_1Types.html#a2c6a29ac1f514900d05c43c34c78a82ca92555c256cc43e43c96055e798e052aa", null ],
      [ "SOL_MEASUREMENT_TYPE_CIELAB", "d8/dcb/classHPLFPSDK_1_1Types.html#a2c6a29ac1f514900d05c43c34c78a82ca1693dab9019490742b81132441a677fb", null ],
      [ "SOL_MEASUREMENT_TYPE_DENSITY", "d8/dcb/classHPLFPSDK_1_1Types.html#a2c6a29ac1f514900d05c43c34c78a82ca7d6e3114cba3c77f1b71be5aa0b00e08", null ]
    ] ],
    [ "SolPrinterState", "d8/dcb/classHPLFPSDK_1_1Types.html#af364715ae9abcffd56c6de6a68d517c5", [
      [ "SOL_STATUS_PRINTER_UNKNOWN", "d8/dcb/classHPLFPSDK_1_1Types.html#af364715ae9abcffd56c6de6a68d517c5a4e902ab203549f2d18ecabfc82059e4f", null ],
      [ "SOL_STATUS_PRINTER_READY", "d8/dcb/classHPLFPSDK_1_1Types.html#af364715ae9abcffd56c6de6a68d517c5a3721b524275cb59f3cbed9d5e2b043ff", null ],
      [ "SOL_STATUS_PRINTER_BUSY", "d8/dcb/classHPLFPSDK_1_1Types.html#af364715ae9abcffd56c6de6a68d517c5a963b41b2bb0dd1bb889fcccdbae8304d", null ],
      [ "SOL_STATUS_PRINTER_WORKING", "d8/dcb/classHPLFPSDK_1_1Types.html#af364715ae9abcffd56c6de6a68d517c5a4afb36ade274cd61e0c8cae3ec914004", null ]
    ] ],
    [ "SolProgressType", "d8/dcb/classHPLFPSDK_1_1Types.html#af86b9700c2006d37562564dd5274f4ab", [
      [ "SOL_PROGRESS_UNKNOWN", "d8/dcb/classHPLFPSDK_1_1Types.html#af86b9700c2006d37562564dd5274f4aba052a688446eb2057b4d13d2764cc1154", null ],
      [ "SOL_PROGRESS_NONE", "d8/dcb/classHPLFPSDK_1_1Types.html#af86b9700c2006d37562564dd5274f4abacbe081f96a3d32d54d5eee5aab91cdb2", null ],
      [ "SOL_PROGRESS_PERCENT", "d8/dcb/classHPLFPSDK_1_1Types.html#af86b9700c2006d37562564dd5274f4aba827411bc44f671f455ce080decb67b43", null ],
      [ "SOL_PROGRESS_SECONDS_REMAINING", "d8/dcb/classHPLFPSDK_1_1Types.html#af86b9700c2006d37562564dd5274f4aba75247ccb7fc3e5d967626833c4765079", null ]
    ] ],
    [ "SolScanStatus", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bb", [
      [ "SOL_STATUS_OPERATION_UNKNOWN", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba08462badcb6a09c7437b8f13e6dbafa0", null ],
      [ "SOL_STATUS_OPERATION_IDLE", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba69e1dde127f86e74a5190864984002ce", null ],
      [ "SOL_STATUS_OPERATION_PREPARING", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bbafcd17f6bf7bdaf3325920d902d0f899c", null ],
      [ "SOL_STATUS_OPERATION_FINISHING", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bbaab9741ff35f947739be6c06840243580", null ],
      [ "SOL_STATUS_OPERATION_PROCESSING", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba51f8744dd6af99d44e1f3d3424aa2b1c", null ],
      [ "SOL_STATUS_OPERATION_PRINTING", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba5735373d670fca555d5cb12fd41c5bfd", null ],
      [ "SOL_STATUS_OPERATION_DRYING", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba14c711e0518ea1ab7fdc2c81c05cfffc", null ],
      [ "SOL_STATUS_OPERATION_CALIBRATING", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba6660cab03176bf5393caf6b3110d73d4", null ],
      [ "SOL_STATUS_OPERATION_SCANNING", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba67065f0bfdf0e8a24034b86e488e5f8d", null ],
      [ "SOL_STATUS_OPERATION_CANCELLING", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba558b06367e49d418ce7c76d4c75a4e31", null ],
      [ "SOL_STATUS_OPERATION_SUCCEEDED", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba9c835c5caaefd98b45ef9571a6ff519a", null ],
      [ "SOL_STATUS_OPERATION_FAILED", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba4f3eb3d196dbf8a8339aa5fa80368069", null ],
      [ "SOL_STATUS_OPERATION_CANCELLED", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bbac4eaa7a1642cd6554f230b970d37c0c7", null ],
      [ "SOL_STATUS_OPERATION_SCAN_ERROR", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba17e3df2a00e771a1243e003a67bd390a", null ],
      [ "SOL_STATUS_OPERATION_SKEW_ERROR", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bbace60fd6aeb84864a15851e9ce2a67dd8", null ],
      [ "SOL_STATUS_OPERATION_TIME_OUT", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bbaa2431c0b4a6737d0838497a0fbdb795f", null ],
      [ "SOL_STATUS_OPERATION_WAITING_QUEUE", "d8/dcb/classHPLFPSDK_1_1Types.html#a2552570d4faa25354b3fc42ead8594bba54f7c7ece13ecd5abbdde00112cd378a", null ]
    ] ],
    [ "Unidirectional", "d8/dcb/classHPLFPSDK_1_1Types.html#a5727c232bd7bc5a9f809b0016564cf16", [
      [ "UNIDIRECTIONAL_OFF", "d8/dcb/classHPLFPSDK_1_1Types.html#a5727c232bd7bc5a9f809b0016564cf16a94fe2a8c96882a6e5c7759b3cb23558e", null ],
      [ "UNIDIRECTIONAL_ON", "d8/dcb/classHPLFPSDK_1_1Types.html#a5727c232bd7bc5a9f809b0016564cf16a5527806652c5050b22411f1024224910", null ]
    ] ],
    [ "VerticalContentAlignment", "d8/dcb/classHPLFPSDK_1_1Types.html#a0401c045564c9517b51593eb7160e1e7", [
      [ "VERTICALCONTENTALIGNMENT_DISABLED", "d8/dcb/classHPLFPSDK_1_1Types.html#a0401c045564c9517b51593eb7160e1e7a135b8fa94859c5360ee7aaa354ff6b67", null ],
      [ "VERTICALCONTENTALIGNMENT_TOP", "d8/dcb/classHPLFPSDK_1_1Types.html#a0401c045564c9517b51593eb7160e1e7a588bd89702499f59c179e1211e238ef0", null ],
      [ "VERTICALCONTENTALIGNMENT_CENTER", "d8/dcb/classHPLFPSDK_1_1Types.html#a0401c045564c9517b51593eb7160e1e7a14313d1ec1406091e2f9b9749e90b691", null ],
      [ "VERTICALCONTENTALIGNMENT_BOTTOM", "d8/dcb/classHPLFPSDK_1_1Types.html#a0401c045564c9517b51593eb7160e1e7a1474d728ec6f5247490a9e24279ff904", null ],
      [ "VERTICALCONTENTALIGNMENT_ALIGN_TO_PLATTEN", "d8/dcb/classHPLFPSDK_1_1Types.html#a0401c045564c9517b51593eb7160e1e7a0036470a37cf0bc19e2abc5d76f02272", null ]
    ] ],
    [ "WhiteDensity", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450f", [
      [ "WHITEDENSITY_UNDEFINED", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa005de071f1cd6e094cc1304a18fba47f", null ],
      [ "WHITEDENSITY_L3", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fadd433ee77b0d46f2efb7e4d5d6a24c27", null ],
      [ "WHITEDENSITY_L4", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa2a216f76e94071336931de2d0be9425c", null ],
      [ "WHITEDENSITY_L5", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa422243e6e5e77a6aa0b4e63e1c213fc6", null ],
      [ "WHITEDENSITY_L6", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa0c7f88ff4fcc07acf5841e0786c00876", null ],
      [ "WHITEDENSITY_L7", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa11706a72890001ca714b7c097e7650e0", null ],
      [ "WHITEDENSITY_L8", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fabf4a93b2fc04ca1432c204106740be3d", null ],
      [ "WHITEDENSITY_L9", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa3d75c19fdf6b8e61dbb224e72ae58e7e", null ],
      [ "WHITEDENSITY_L10", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa3004ea6c06cb1c1a564f992363156126", null ],
      [ "WHITEDENSITY_L11", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450faaf67a041f080b8e5a5a54fb9bb387ebe", null ],
      [ "WHITEDENSITY_L12", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fab7962fb9c072966241ddb70b08e6e7ae", null ],
      [ "WHITEDENSITY_L13", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa5afdcb9d1b623d31661b11dd5542f1df", null ],
      [ "WHITEDENSITY_L14", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa33708a982d38de5848c0bb93e2d9b954", null ],
      [ "WHITEDENSITY_L15", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa80e6efabf27fe9a0a0d5f829455c5737", null ],
      [ "WHITEDENSITY_L16", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa552b683844a9fe53e4a65491e8711632", null ],
      [ "WHITEDENSITY_L17", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa4ba102cfd3f10e341b2b0f387ade7adf", null ],
      [ "WHITEDENSITY_L18", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fae282cd4cf7026d6af24e4a3d4821c4a8", null ],
      [ "WHITEDENSITY_L19", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa16e147dda6e73a1ca50d0ff1c648c8f8", null ],
      [ "WHITEDENSITY_L20", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450facc14df0e9178ba0b1d30118e479039ca", null ],
      [ "WHITEDENSITY_L21", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450faae046aad623f6be81a1e1cc6477c1f41", null ],
      [ "WHITEDENSITY_L22", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa1b0cb0f162b21c553deae10babf5fbbc", null ],
      [ "WHITEDENSITY_L23", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa2f241d44f2e3db1ddc1dfaaf64dc4a18", null ],
      [ "WHITEDENSITY_L24", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa8e6e6c529e4936df7aec052429b5ba9b", null ],
      [ "WHITEDENSITY_L25", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa34d10b0524ec5b5ec6e7f247a31c14c7", null ],
      [ "WHITEDENSITY_L26", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa374717ac14f92fa2c0c090c907624e9e", null ],
      [ "WHITEDENSITY_L27", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa8d2e69b720d4549ec47ce5ac3174e42a", null ],
      [ "WHITEDENSITY_L28", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450fa6c8c1ae2abf917028dfced871ce68c00", null ],
      [ "WHITEDENSITY_L29", "d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450faa83aea8583068007cac8801c2b27c19d", null ]
    ] ],
    [ "WhiteMode", "d8/dcb/classHPLFPSDK_1_1Types.html#a76344a58ea34880aaa17d2141e5485ba", [
      [ "WHITEMODE_UNDEFINED", "d8/dcb/classHPLFPSDK_1_1Types.html#a76344a58ea34880aaa17d2141e5485baa493e018a82bc65631e7765e162271406", null ],
      [ "WHITEMODE_SPOT", "d8/dcb/classHPLFPSDK_1_1Types.html#a76344a58ea34880aaa17d2141e5485baa6fe470b71ba093a3dcffd91f326fc2b3", null ],
      [ "WHITEMODE_UF", "d8/dcb/classHPLFPSDK_1_1Types.html#a76344a58ea34880aaa17d2141e5485baa9e7fb520200290d66fb300ad65c045e5", null ],
      [ "WHITEMODE_OF", "d8/dcb/classHPLFPSDK_1_1Types.html#a76344a58ea34880aaa17d2141e5485baa53b5d5e66d0c784c175bc30cdde9a5b2", null ],
      [ "WHITEMODE_SW3L", "d8/dcb/classHPLFPSDK_1_1Types.html#a76344a58ea34880aaa17d2141e5485baa6797ec7a378a845bd7e4c2f78d8d4350", null ],
      [ "WHITEMODE_SW4L", "d8/dcb/classHPLFPSDK_1_1Types.html#a76344a58ea34880aaa17d2141e5485baa89ae9c8f7c78980c6206d521093f782f", null ],
      [ "WHITEMODE_SW5L", "d8/dcb/classHPLFPSDK_1_1Types.html#a76344a58ea34880aaa17d2141e5485baab8654c158bebab44f33258b816462a42", null ]
    ] ],
    [ "WhiteShrink", "d8/dcb/classHPLFPSDK_1_1Types.html#a6826ad9c1694e8f4bc25d1c7fed5ba6a", [
      [ "WHITESHRINK_DISABLED", "d8/dcb/classHPLFPSDK_1_1Types.html#a6826ad9c1694e8f4bc25d1c7fed5ba6aa158387fc961b7ce0e38d096557315f27", null ],
      [ "WHITESHRINK_ENABLED", "d8/dcb/classHPLFPSDK_1_1Types.html#a6826ad9c1694e8f4bc25d1c7fed5ba6aaf5e81278fe9884022cc800f86cc556f0", null ]
    ] ],
    [ "YCutter", "d8/dcb/classHPLFPSDK_1_1Types.html#a92861490b2b834bd131025e61dcbd60c", [
      [ "YCUTTER_ENABLED", "d8/dcb/classHPLFPSDK_1_1Types.html#a92861490b2b834bd131025e61dcbd60ca55bbed6b683ea7671e71233d74b83193", null ],
      [ "YCUTTER_DISABLED", "d8/dcb/classHPLFPSDK_1_1Types.html#a92861490b2b834bd131025e61dcbd60ca52c3b940742dc44265d7d5faa6ca110f", null ]
    ] ]
];