//////////////////////////////////////////////////////////////////////////////
/**
* @file  printSample.cpp
* @date   Fri Dec  16 11:27:33 CEST 2016
* @brief  C++ CodeSample.
* Sample Code that demostrates the usage of a print workflow.
*
* In order to make it clearer this code does not include proper error checking
* (some asserts are include instead) nor user iteraction.
*
* @par &copy; Copyright Hewlett-Packard Company, 2000-2016.
* All rights reserved. Copying or other reproduction of this program except
* for archival purposes is prohibited without written consent of
* Hewlett-Packard Company.
*/
////////////////////////////////////////////////////////////////////////////////

#include "printSample.h"

#include <iostream>
#include <iostream>
#include <fstream>
#include <assert.h>

#include "tiff/tiffUtils.h"
#include <vector>

#include <map>
#include <algorithm>

#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/tree.h>
#include <libxml/xpathInternals.h>

// Constants used for parsing of the printmode list xml
const std::string XPATH_PRINTMODE_FILTER = "//printmodeList:printmode";
const std::string XPATH_PRINTMODE_NS = "http://www.bpo.hp.com/printmodeList";
const std::string XPATH_PRINTMODELIST = "printmodeList";

// Width of the machine in inches (44 inches here)
const float machineWidthLimitInches = 44;


// IMemoryHandler definition
// An object that implements this interface must be provided to the newJob methods.
// In this implementation the acquire buffer allocates the memory where the HPLFPSDK will store output data
// In this implementation the release buffer will write the buffer data to an output file and free the buffer.
// This is an implementation choice, here we want simplicity for the example, an alternative solution
// is to allocate a set of buffers and reuse them.
class Memory : HPLFPSDK::IJobPacker::IMemoryHandler{
public:
    Memory(const char* outfilename = NULL)
    {
        if (outfilename != NULL)
        {
            filePtr.open(outfilename, std::ofstream::trunc | std::ofstream::binary);
            assert(filePtr.is_open());
        }
    }
    ~Memory()
    {
        if (filePtr.is_open())
            filePtr.close();
    }

    void* acquireBuffer(uint32_t numBytes);
    void  releaseBuffer(const uint8_t *buffer, uint32_t numBytes);
private:
    std::ofstream filePtr;
};
void* Memory::acquireBuffer(uint32_t numBytes){
    return new (std::nothrow) uint8_t[numBytes];

}
void Memory::releaseBuffer(const uint8_t *buffer, uint32_t numBytes)
{
    if (filePtr.is_open())
    {
        filePtr.write((const char*)buffer, numBytes);
        filePtr.flush();
    }
    delete[] buffer;
    return;

}


// Helper function
HPLFPSDK::Types::RenderingResolution convertToHPLFPSDKResolution(uint32_t resolution)
{

    HPLFPSDK::Types::RenderingResolution rendRes = HPLFPSDK::Types::RENDERINGRESOLUTION_RES_200;
    switch (resolution)
    {
    case 200:
        rendRes = HPLFPSDK::Types::RENDERINGRESOLUTION_RES_200;
        break;
    case 300:
        rendRes = HPLFPSDK::Types::RENDERINGRESOLUTION_RES_300;
        break;
    case 600:
        rendRes = HPLFPSDK::Types::RENDERINGRESOLUTION_RES_600;
        break;
    case 1200:
        rendRes = HPLFPSDK::Types::RENDERINGRESOLUTION_RES_1200;
        break;
    default:
        std::cout << "ERROR: unsupported resolution %d \n";
        assert(0);
    }
    return rendRes;
}

// To fill in the jobSettings object
bool fillJobSettings(HPLFPSDK::IJobPacker * jobPacker, HPLFPSDK::IJobPacker::IJobSettings* &jobSettings)
{
    jobSettings = jobPacker->getJobSettingsContainer();
    if (jobSettings != NULL)
    {
        HPLFPSDK::Types::Result res = jobSettings->setJobUuid("123458678-abcd-abcd-abcd-1234567890ab");//JobUUID is mandatory
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, jobUUID could not be set" << std::endl;
        }
        res = jobSettings->setJobName("Job-Printing-Sample");//JobName is Mandatory
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, rendering resolution could not be set" << std::endl;
        }
        res = jobSettings->setAccountId("12345");//Account ID is Mandatory
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, Account Id could not be set" << std::endl;
        }
        res = jobSettings->setApplicationName("Samples ");//AppName is Mandatory
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, application name could not be set" << std::endl;
        }
        res = jobSettings->setPartnerId("HPLFPSDK Samples ID");//partnerID is Mandatory
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, partner id could not be set" << std::endl;
        }
        res = jobSettings->setApplicationVersion("1.0");//Application Version is Mandatory
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, application version could not be set" << std::endl;
        }
        res = jobSettings->setJobCopies(1);
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, jobCopies could not be set" << std::endl;
        }

    }
    else
    {
        std::cout << "Error Filling in Job Settings" << std::endl;
        return false;
    }

    return true;

}

// To fill in the pageSettings object
bool fillPageSettings(HPLFPSDK::IJobPacker * jobPacker, HPLFPSDK::IJobPacker::IPageSettings* &pageSettings, uint32_t imageWidth, uint32_t imageHeight, HPLFPSDK::Types::RenderingResolution resolution)
{
    pageSettings = jobPacker->getPageSettingsContainer();
    if (pageSettings != NULL)
    {
        HPLFPSDK::Types::Result res = pageSettings->setRenderingResolution(resolution);
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, rendering resolution could not be set" << std::endl;
        }
        HPLFPSDK::Types::MetricDistance twoInches;
        twoInches.units = 2 * 9600;
        twoInches.unitsPerInch = 9600;
        res = pageSettings->setBottomMargin(twoInches);
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, bottom margin could not be set" << std::endl;
        }
        res = pageSettings->setTopMargin(twoInches);
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, top margin could not be set" << std::endl;
        }
        res = pageSettings->setRightMargin(twoInches);
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, right margin could not be set" << std::endl;
        }
        res = pageSettings->setLeftMargin(twoInches);
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, left margin could not be set" << std::endl;
        }

        HPLFPSDK::Types::MetricDistance d;
        d.unitsPerInch = 9600;
        d.units = (imageWidth * 9600) / resolution + 2 * twoInches.units;
        d.units = (d.units > (machineWidthLimitInches * 9600)) ? (machineWidthLimitInches * 9600) : d.units;
        res = pageSettings->setWidth(d);
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, width could not be set" << std::endl;
        }
        d.units = (imageHeight * 9600) / resolution + 2 * twoInches.units;
        res = pageSettings->setLength(d);
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, length could not be set" << std::endl;
        }
        res = pageSettings->setMediaId("1000");
        if (res != HPLFPSDK::Types::RESULT_OK)
        {
            std::cout << "Error, media ID could not be set" << std::endl;
        }
    }
    else
    {
        std::cout << "Error Filling in Page Settings" << std::endl;
        return false;
    }

    return true;

}

// Helper class : a printmode selection as a pair key X value
class Selector
{
public:
    std::string name_;
    std::string value_;

    void dump()
    {
        std::cout << "key : " << name_ << " value : " << value_ << std::endl;
    }
};

// A rasterConfig as a map of pair key X value
// please note that there are no reference to the name of the fields
// => this code is generic and should not need updates depending in the machine
class RasterConfig
{
public:
    std::map<std::string, std::string> config_;

    void dump()
    {
        std::cout << "Config : ";
        for (auto it = config_.begin(); it != config_.end(); it++)
        {
            std::cout << it->first << "=" << it->second << " ";
        }
        std::cout << std::endl;
    }

    bool getField(std::string key, std::string &value)
    {
        bool cr = false;

        auto foundAttribute = config_.find(key);
        if (foundAttribute != config_.end())
        {
            cr = true;
            value = foundAttribute->second;
        }
        return cr;
    }
};

// A PrintMode is a composition of  :
//    1-a list of user readable selectors to be used for instance to have the user choose a printmode amongst the availables.
//    2-a list of selectors to be programmed with a sequence of calls to the IPageSettings::setSelector method
//    3-a list of the RasterConfig(s) supported by the printmode
// the selectConfig can be used to select the RasterConfig(s) of the printmode that fullfill a criteria (i.e. : resolution=600, chunky, contone)
// In this sample code, the criteria is derived from the input Tiff file attributes.
class PrintMode
{
public:
    std::map<std::string, std::string> firstLine_;
    std::vector<Selector> selectors_;
    std::vector<RasterConfig> configs_;

    void dump()
    {
        for (std::map<std::string, std::string>::iterator it = firstLine_.begin(); it != firstLine_.end(); it++)
        {
            std::cout << it->first << "=" << it->second << "   ";
        }
        std::cout << std::endl;

        for (std::vector<Selector>::iterator it = selectors_.begin(); it != selectors_.end(); it++)
        {
            it->dump();
        }

        for (std::vector<RasterConfig>::iterator it = configs_.begin(); it != configs_.end(); it++)
        {
            it->dump();
        }

        std::cout << std::endl;
    }

    uint32_t selectConfig(std::map<std::string, std::string> &criteria, std::vector<RasterConfig> &selected)
    {
        for (std::vector<RasterConfig>::iterator it = configs_.begin(); it != configs_.end(); it++)
        {
            bool couldGo = true;
            for (std::map<std::string, std::string>::iterator oneCriteria = criteria.begin(); (oneCriteria != criteria.end()) && couldGo; oneCriteria++)
            {
                std::map<std::string, std::string>::iterator foundAttribute = it->config_.find(oneCriteria->first);
                if (foundAttribute != it->config_.end())
                {
                    couldGo = (oneCriteria->second == foundAttribute->second);
                }
            }
            if (couldGo)
            {
                selected.push_back(*it);
            }
        }
        return selected.size();
    }
};

// A PrintmodeList is a composition of :
//    1-a media Id of the media that supports these printmodes
//    2-a list of printmodes
// the selectPrintModes can be used to select the printmode(s) from the list that fullfill a citeria based on the user readable selectors
// note that this code does not make reference to the value or name of the criteria, there again it should be generic enough to simplify adapatation (if any) to new models introduction
class PrintModeList
{
public:
    std::string mediaId_;
    std::vector<PrintMode> printModes_;

    void dump()
    {
        std::cout << "mediaId : " << mediaId_ << std::endl;
        for (std::vector<PrintMode>::iterator it = printModes_.begin(); it != printModes_.end(); it++)
        {
            it->dump();
        }
    }

    uint32_t selectPrintModes(std::map<std::string, std::string> &criteria, PrintModeList &selected)
    {
        selected.mediaId_ = mediaId_;
        for (std::vector<PrintMode>::iterator it = printModes_.begin(); it != printModes_.end(); it++)
        {
            bool couldGo = true;
            for (std::map<std::string, std::string>::iterator oneCriteria = criteria.begin(); (oneCriteria != criteria.end()) && couldGo; oneCriteria++)
            {
                std::map<std::string, std::string>::iterator foundAttribute = it->firstLine_.find(oneCriteria->first);
                if (foundAttribute != it->firstLine_.end())
                {
                    couldGo = (oneCriteria->second == foundAttribute->second);
                }
            }
            if (couldGo)
            {
                selected.printModes_.push_back(*it);
            }
        }
        return selected.printModes_.size();
    }
};

// a method to get the XML from the MediaManager::getSupportedPrintModes API and parse it.
// somehow it builds the set of object "printmode database" for a target media.
void getPrintModeList(HPLFPSDK::IDevice *device, PrintModeList &printModeList)
{
    std::cout << "getPrintModeList \n";

    HPLFPSDK::IMediaManager *mediaManager_ = device->getMediaManager();
    char mediaId[] = "1000";
    char *charPointer = NULL;
    size_t longLength = 0;
    HPLFPSDK::Types::Result returnCode;

    // call the mediaManagerAPI
    returnCode = mediaManager_->getSupportedPrintmodes(mediaId, &charPointer, longLength);

    if (returnCode != HPLFPSDK::Types::RESULT_OK)
    {
        std::cout << "ERROR GETTING PRINTMODES: " << returnCode << std::endl;
        return;
    }

    // parse the XML
    xmlDocPtr xmlDecrypted = xmlParseMemory(charPointer, longLength);

    if (xmlDecrypted == NULL)
    {
        std::cout << "PRINTMODES LIST NOT PARSED SUCCESFULLY" << std::endl;
        hplfpsdk_deleteBuffer(&charPointer);
        return;
    }

    xmlXPathInit();
    xmlXPathContextPtr context = xmlXPathNewContext(xmlDecrypted);
    if (context == NULL)
    {
        std::cout << "RESULT_ERROR_MEMORY" << std::endl;
        hplfpsdk_deleteBuffer(&charPointer);
        xmlFreeDoc(xmlDecrypted);
        return;
    }

    // build the list of printmode nodes

    xmlXPathRegisterNs(context, BAD_CAST XPATH_PRINTMODELIST.c_str(), BAD_CAST XPATH_PRINTMODE_NS.c_str());
    std::string pathFilter(XPATH_PRINTMODE_FILTER.c_str());
    xmlXPathObjectPtr xmlobject = xmlXPathEval((const xmlChar *)(pathFilter.c_str()), context);

    // for each node (printmode), create a prinmode object and add it to the list
    for (int i = xmlobject->nodesetval->nodeNr - 1; i >= 0; --i)
    {
        xmlNodePtr curNode = xmlobject->nodesetval->nodeTab[i];

        // check if it belongs to a halftone chapter
        // due to a recurrent issue in the printer firmware we cannot rely on the bpp field
        // we must check if the printmode is in the contone or in the halftone chapter.
        bool contone = (std::string((char *)curNode->parent->name).find("supportedPrintmodesHalftonePath") == std::string::npos);

        PrintMode onePrintMode;
        xmlAttr* printmodeAttribute = curNode->properties;
        // read the attributes
        while (printmodeAttribute != 0)
        {
            onePrintMode.firstLine_.emplace(std::string((char *)printmodeAttribute->name), std::string((char *)printmodeAttribute->children->content));
            printmodeAttribute = printmodeAttribute->next;
        }

        // add an attribute for halftone since it is a printmode selection criteria
        // it should be in the bpp attribute but there is an issue in the WS => this is a workaround
        if (contone)
        {
            onePrintMode.firstLine_.emplace(std::string("Contone"), std::string("true"));
        }
        else
        {
            onePrintMode.firstLine_.emplace(std::string("Contone"), std::string("false"));
        }

        xmlNodePtr childNode = curNode->children;
        while (childNode != 0)
        {
            if (std::string((char *)childNode->name) == "Selectors")
            {
                xmlNodePtr oneSelectorElem = childNode->children;
                while (oneSelectorElem != 0)
                {
                    xmlAttr* selectorAttribute = oneSelectorElem->properties;
                    Selector oneSelector;
                    while (selectorAttribute != 0)
                    {
                        if (strcmp((char *)selectorAttribute->name, "key") == 0)
                        {
                            oneSelector.name_ = std::string((char *)selectorAttribute->children->content);
                        }
                        else if (strcmp((char *)selectorAttribute->name, "value") == 0)
                        {
                            oneSelector.value_ = std::string((char *)selectorAttribute->children->content);
                        }
                        selectorAttribute = selectorAttribute->next;
                    }
                    oneSelectorElem = oneSelectorElem->next;
                    onePrintMode.selectors_.push_back(oneSelector);
                }
            }
            else if (std::string((char *)childNode->name) == "SupportedRasterConfigs")
            {
                xmlNodePtr oneConfigElem = childNode->children;
                while (oneConfigElem != 0)
                {
                    xmlAttr* configAttribute = oneConfigElem->properties;
                    RasterConfig oneConfig;
                    while (configAttribute != 0)
                    {
                        oneConfig.config_.emplace(std::string((char *)configAttribute->name), std::string((char *)configAttribute->children->content));
                        configAttribute = configAttribute->next;
                    }
                    oneConfigElem = oneConfigElem->next;
                    onePrintMode.configs_.push_back(oneConfig);
                }

            }
            childNode = childNode->next;
        }
        printModeList.printModes_.push_back(onePrintMode);
        printModeList.mediaId_ = std::string(mediaId);
    }

    hplfpsdk_deleteBuffer(&charPointer);
    xmlXPathFreeContext(context);
    if (xmlobject)
    {
        xmlXPathFreeObject(xmlobject);
    }
    xmlFreeDoc(xmlDecrypted);
}

// This function is the justification of this sample.
// It uses the HPLFPSDK to convert a Tiff input file into a printable rs file.
// For this it uses the IMediaManager::getSupportedPrintmode to get the printmode list and the rasterconfig list
// The use is prompted to choose between the available printmodes and rasterconfig
// Only valid options are proposed (based on the characteristics of the TIFF)
// The tiff is supposed to be RGBX since I could not find a way to read this data from the TIFF header.
// An ISV that implement the Tiff generation (rendering) will probably render depending on the supported format.
void HPLFPSDK_SAMPLES::testJustPrint(HPLFPSDK::IDevice* printer, std::string in, std::string out)
{

    std::string previewName = "./Tiff_Images/FACES_RGBX_600.jpg";

    TiffReader reader;
    reader.configure(in.c_str());
    // Start reading TIFF input to get data
    uint32_t tiffImageWidth = reader.getImageWidth();
    uint32_t tiffImageHeight = reader.getImageHeight();
    uint32_t tiffResolutionX = reader.getXResolution();
    uint32_t tiffResolutionY = reader.getYResolution(); 
    uint32_t tiffResolution = reader.getXResolution(); 
    uint32_t tiffRowStride = reader.getRowLength();
    uint32_t tiffColors = reader.getColors();
    uint32_t tiffBpp = reader.getBpp();
    std::string tiffChunky = (reader.isChunky() == 1) ? "true" : "false";
    std::string tiffContone = (tiffBpp == 8) ? "true" : "false";
    std::cout << "Image Width: " << tiffImageWidth << std::endl;
    std::cout << "Image Height: " << tiffImageHeight << std::endl;
    std::cout << "ResolutionX: " << tiffResolutionX << std::endl;
    std::cout << "ResolutionY: " << tiffResolutionY << std::endl;
    std::cout << "Resolution: " << tiffResolution << std::endl;
    std::cout << "Row Length: " << tiffRowStride << std::endl;
    std::cout << "Colors: " << tiffColors << std::endl;
    std::cout << "Bpp: " << tiffBpp << std::endl;
    std::cout << "Chunky: " << tiffChunky << std::endl;
    std::cout << "Contone: " << tiffContone << std::endl;

    // read the supported PModes list for this printer
    PrintModeList printModeList;
    getPrintModeList(printer, printModeList);

    // Build the printmode selection criteria
    std::map<std::string, std::string> pmCriteria;
    pmCriteria.emplace("Contone", tiffContone);

    // Build the config selection criteria
    //BUSCA UNA RASTER CONFIG COMPATIBLE
    std::map<std::string, std::string> configCriteria;
    configCriteria.emplace("contone", tiffContone);
    configCriteria.emplace("chunky", tiffChunky);
    configCriteria.emplace("xres", std::to_string(tiffResolutionX));
    configCriteria.emplace("vres", std::to_string(tiffResolutionY));
    configCriteria.emplace("res", std::to_string(tiffResolution));
    configCriteria.emplace("numColorsPerPlane", (reader.isChunky() == 1) ? std::to_string(tiffColors) : "1");

    // Go get the candidates Printmodes
    PrintModeList selectedPrintModeList;
    printModeList.selectPrintModes(pmCriteria, selectedPrintModeList);

    // Select the Printmodes that have at least one suitable raster format
    PrintModeList goodPrintModeList;
    for (auto it = selectedPrintModeList.printModes_.begin(); it != selectedPrintModeList.printModes_.end(); it++)
    {
        // Go get the candidates Formats
        std::vector<RasterConfig> selectedConfigList;
        it->selectConfig(configCriteria, selectedConfigList);

        // This printmode has (at least) a suitable format
        if (selectedConfigList.size() != 0)
        {
            goodPrintModeList.printModes_.push_back(*it);
        }
    }

    // if not PM X RasterConfig combination works for this file, report the situation
    if (goodPrintModeList.printModes_.size() == 0)
    {
        std::cout << "Could not find a suitable printmodeXrasterFormat combination for this file" << std::endl;
        return;
    }

    // let the user choose a printmode amongst the supported onces
    std::cout << "These are the printmodes that support the input file :" << std::endl;
    {
        uint32_t i = 1;
        for (auto it = goodPrintModeList.printModes_.begin(); it != goodPrintModeList.printModes_.end(); it++)
        {
            std::cout << i << " : ";
            auto firstLine = it->firstLine_;
            for (std::map<std::string, std::string>::iterator itfirst = firstLine.begin(); itfirst != firstLine.end(); itfirst++)
            {
                std::cout << itfirst->first << "=" << itfirst->second << "   ";
            }
            std::cout << std::endl;
            i++;
        }
    }
    std::cout << "please enter the index of the printmode to use [1-" << goodPrintModeList.printModes_.size() << "] : ";
    uint32_t  chosenPrintmodeIndex = 1;
    while ((chosenPrintmodeIndex < 1) || ((chosenPrintmodeIndex > goodPrintModeList.printModes_.size())))
    {
        std::cin >> chosenPrintmodeIndex;
    }
    std::cout << "printmode to use : " << chosenPrintmodeIndex << std::endl;

    // Print with the chosen printmode
    auto it = goodPrintModeList.printModes_[chosenPrintmodeIndex - 1];
    {
        std::cout << "try to print using the printmode : " << std::endl;
        it.dump();

        // Go get the candidates Formats
        std::vector<RasterConfig> selectedConfigList;
        it.selectConfig(configCriteria, selectedConfigList);

        // Let the user chose a format
        uint32_t i = 1;
        std::cout << "These are the raster configs that support the input file for the chosen printmode :" << std::endl;
        for (auto itConf = selectedConfigList.begin(); itConf != selectedConfigList.end(); itConf++)
        {
            std::cout << i << " : ";
            itConf->dump();
            i++;
        }
        std::cout << std::endl;
        std::cout << "please enter the index of the config to use : ";
        std::cout << "please enter the index of the config to use [1-" << selectedConfigList.size() << "] : ";

        uint32_t  chosenConfigIndex = 1;

        while ((chosenConfigIndex < 1) || ((chosenConfigIndex > selectedConfigList.size())))
        {
            std::cin >> chosenConfigIndex;
        }
        std::cout << "config to use : " << chosenConfigIndex << std::endl;

        // Print with the chosen rasterformat
        auto itConfig = selectedConfigList[chosenConfigIndex];
        {
            std::string key;
            itConfig.getField("Key", key);
            std::cout << "key : " << key << std::endl;

            // create a JobPakcer
            std::cout << "before jobPacker " << std::endl;

            HPLFPSDK::IJobPacker * jobPacker = printer->createJobPackerUsingRasterConfiguration(key.c_str());
            if (jobPacker == NULL)
            {
                std::cout << "Error creating the JobPacker" << std::endl;
            }

            HPLFPSDK::IJobPacker::IJobSettings* jobSettings;
            fillJobSettings(jobPacker, jobSettings);
            std::cout << "before newJob " << std::endl;
            HPLFPSDK::Types::Result res;
            // create a MemoryHandler, we could reuse one.

            HPLFPSDK::IJobPacker::IMemoryHandler * Mem = (HPLFPSDK::IJobPacker::IMemoryHandler *) new Memory(out.c_str());
            res = jobPacker->newJob(jobSettings, Mem, NULL, NULL);
            if (res != HPLFPSDK::Types::RESULT_OK)
            {
                std::cout << "Error creating the Job" << std::endl;
                long length;
                char *charPointer;
                jobSettings->dumpToChar(&charPointer, &length);
                std::cout << "job settings : " << charPointer << std::endl;
                hplfpsdk_deleteBuffer(&charPointer);
            }
            std::cout << "after newJob " << std::endl;

            // new page
            uint32_t bandHeight = 64;
            HPLFPSDK::IJobPacker::IPageSettings* pageSettings;
            HPLFPSDK::Types::RenderingResolution r = convertToHPLFPSDKResolution(tiffResolution);
            fillPageSettings(jobPacker, pageSettings, tiffImageWidth, tiffImageHeight, r);
            for (auto itSelector = it.selectors_.begin(); itSelector != it.selectors_.end(); itSelector++)
            {
                pageSettings->setSelector(itSelector->name_.c_str(), itSelector->value_.c_str());

            }
            std::cout << "before addPage " << std::endl;

            HPLFPSDK::IJobPacker::pageid_t pageId;
            res = jobPacker->addPage(pageSettings, pageId);
            if (res != HPLFPSDK::Types::RESULT_OK)
            {
                std::cout << "ERROR : addPage " << std::endl;
                long length;
                char *charPointer;
                pageSettings->dumpToChar(&charPointer, &length);
                std::cout << "page settings : " << charPointer << std::endl;
                hplfpsdk_deleteBuffer(&charPointer);
            }

            HPLFPSDK::IJobPacker::Preview fakePreview;
            std::vector<char> fakeBuffer;

            // Generate preview images.
            std::ifstream input1(previewName.c_str(), std::ios::binary);
            // copies all data into buffer
            fakeBuffer = std::vector<char>((std::istreambuf_iterator<char>(input1)), (std::istreambuf_iterator<char>()));

            fakePreview.buffer_ = reinterpret_cast<uint8_t*> (&fakeBuffer[0]);
            fakePreview.numBytes_ = (uint32_t)fakeBuffer.size();
            jobPacker->addPreview(pageId, fakePreview);

            // black Magic
            uint32_t imageWidth = ((uint32_t)(((tiffImageWidth)+63) / 64)) * 64;// round image width to a multiple of 64 pixels

            // startRaster
            uint32_t rowStride = 0; // a.k.a. bytes per line
            std::cout << "before startRaster " << std::endl;
            res = jobPacker->startRasterKey(pageId, key.c_str(), imageWidth, tiffImageHeight, &rowStride);
            std::cout << "after startRaster " << std::endl;

            if (res != HPLFPSDK::Types::RESULT_OK)
            {
                std::cout << "ERROR : startRaster " << std::endl;
            }


            // prepare variables to send the data
            uint32_t bandSize = 0;
            if (tiffChunky == "true")
            {
                bandSize = imageWidth * tiffColors  * bandHeight;
            }
            else
            {
                bandSize = imageWidth * bandHeight;
            }

            // send the data
            uint32_t endRow = 0;
            uint32_t rowRangeId = 0;
            uint32_t pageBandHeight = bandHeight;

            while (endRow < tiffImageHeight - 1)
            {
                // define row range
                uint32_t startRow = rowRangeId * pageBandHeight;
                endRow = startRow + pageBandHeight - 1;
                if (endRow > tiffImageHeight - 1)
                {
                    endRow = tiffImageHeight - 1;
                    pageBandHeight = endRow - startRow + 1;
                }
                // read row range
                if (tiffChunky == "true")
                {
                    // chunky
                    uint8_t * band = new uint8_t[bandSize];           // raster band read from TIFF reader
                    reader.readRowRange(startRow, endRow, band, 0, rowStride);
                    res = jobPacker->addRasterData(pageId, rowStride, pageBandHeight, startRow, band);
                    delete[] band;
                    if (res != HPLFPSDK::Types::RESULT_OK)
                    {
                        std::cout << "ERROR : addRasterData " << std::endl;
                        printer->discardJobPacker(jobPacker);
                        return;
                    }

                }
                else
                {
                    // planar
#if 0
                    HPLFPSDK::IJobPacker::RS_buffer buffer; // planar raster band packet passed to the compressor
                    buffer.numPlane_ = tiffColors;
                    buffer.buffer = new uint8_t *[tiffColors];
                    memset(buffer.buffer, 0, numberOfPlanes*sizeof(uint8_t*));

                    for (uint8_t planeNum = 0; planeNum < tiffColors; planeNum++)
                    {
                        std::cout << "readRowRange" << startRow << " " << endRow << " " << planeNum << " " << rowStride << std::endl;
                        buffer.buffer[planeNum] = new uint8_t[bandSize];
                        memset(buffer.buffer[planeNum], 0, bandSize);

                        reader.readRowRange(startRow, endRow, buffer.buffer[planeNum], planeNum, rowStride);
                        std::cout << "after readRowRange " << std::endl;
                    }
                    res = jobPacker->addRasterDataRSBuffer(pageId, rowStride, pageBandHeight, startRow, buffer);
                    for (uint8_t planeNum = 0; planeNum < tiffColors; planeNum++)
                    {
                        delete[] buffer.buffer[planeNum];
                    }
                    delete[] buffer.buffer;
                    if (res != HPLFPSDK::Types::RESULT_OK)
                    {
                        std::cout << "ERROR : addRasterData " << resultToString(res) << std::endl;
                        printer->discardJobPacker(jobPacker);
                        return;
                    }
#endif
                }
                rowRangeId++;
            }

            // end raster
            res = jobPacker->endRaster(pageId);
            if (res != HPLFPSDK::Types::RESULT_OK)
            {
                std::cout << "ERROR : endRaster " << std::endl;
            }


            // end page
            res = jobPacker->endPage(pageId);
            if (res != HPLFPSDK::Types::RESULT_OK)
            {
                std::cout << "ERROR : endPage " << std::endl;
            }


            // end job
            res = jobPacker->endJob();
            if (res != HPLFPSDK::Types::RESULT_OK)
            {
                std::cout << "ERROR : endJob " << std::endl;
            }

            printer->discardJobPacker(jobPacker);
        }
    }
}