var searchData=
[
  ['wakeprinter',['wakePrinter',['../d0/dbc/classHPLFPSDK_1_1IRemoteManager.html#a8d7b5ccc6bf2aeead5ec17688fe6f868',1,'HPLFPSDK::IRemoteManager']]]
];
