var searchData=
[
  ['jobcancel',['jobCancel',['../d3/d96/classHPLFPSDK_1_1IJobPacker.html#a4a1590bfdb832e3d8317460820ddc458',1,'HPLFPSDK::IJobPacker']]]
];
