var searchData=
[
  ['node',['node',['../d0/d97/struct__HPLFPSDK__GUID.html#af956d08031c0a482dc53ab294cc01b45',1,'_HPLFPSDK_GUID']]],
  ['numbytes_5f',['numBytes_',['../df/dcf/classHPLFPSDK_1_1IJobPacker_1_1Preview.html#aaa96cd96f87b42aa0733196ff93614bb',1,'HPLFPSDK::IJobPacker::Preview']]],
  ['numplane_5f',['numPlane_',['../d5/d35/classHPLFPSDK_1_1IJobPacker_1_1RS__buffer.html#a9ec5371448dd6fe3ad412ce22db0ea15',1,'HPLFPSDK::IJobPacker::RS_buffer']]]
];
