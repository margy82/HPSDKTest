var searchData=
[
  ['transmissionstatuscallback',['transmissionStatusCallback',['../d3/d96/classHPLFPSDK_1_1IJobPacker.html#a253500680c9e24e2d60d33562a289bf3',1,'HPLFPSDK::IJobPacker']]]
];
