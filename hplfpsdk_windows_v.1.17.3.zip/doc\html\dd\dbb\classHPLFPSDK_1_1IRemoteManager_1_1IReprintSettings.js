var classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings =
[
    [ "addPage", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#a32abf30ba2e93b1988029ebccfdcb942", null ],
    [ "setAccountId", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#a781f6a494bf90f96123e753093db3f75", null ],
    [ "setBillable", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#a69c63b31d422bae57d85c9d9e0d3073d", null ],
    [ "setComment", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#a7964e4d0d7fefcff055a15c04c46ba4e", null ],
    [ "setJobToken", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#a2ab806a0b77f3d7d2a20971b3ad3b097", null ],
    [ "setMediaDestination", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#aa627a425d94e3d29afce95a95070b58b", null ],
    [ "setMediaSource", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#aa0e609184db2bdc7959dcd8dacb27419", null ],
    [ "setNumCopies", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#aa280c71a2d7fa2f475bd2370920bbc2b", null ],
    [ "setProjectId", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#abe6ab5a010a3d25efe431f8036205b34", null ],
    [ "setUserName", "dd/dbb/classHPLFPSDK_1_1IRemoteManager_1_1IReprintSettings.html#a19adb2dcbe693c7b5f55d9ee9294cc47", null ]
];