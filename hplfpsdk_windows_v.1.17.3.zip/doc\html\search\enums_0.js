var searchData=
[
  ['booleanplusdefault',['BooleanPlusDefault',['../d8/dcb/classHPLFPSDK_1_1Types.html#a46dfc76761bdc9bd07ebfcbd24df31a6',1,'HPLFPSDK::Types::BooleanPlusDefault()'],['../d9/d49/types_8h.html#a9efcfd1f0a6ec9e660f6ca333b96d3dc',1,'BooleanPlusDefault():&#160;types.h']]],
  ['borderlessmethod',['BorderlessMethod',['../d8/dcb/classHPLFPSDK_1_1Types.html#a7c0b4e1c6b91c90f18802de6c7ed6fce',1,'HPLFPSDK::Types::BorderlessMethod()'],['../d9/d49/types_8h.html#a7b56c0e58c648854a457cf7e115d9806',1,'BorderlessMethod():&#160;types.h']]]
];
