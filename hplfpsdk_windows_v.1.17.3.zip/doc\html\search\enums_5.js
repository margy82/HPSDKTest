var searchData=
[
  ['glossenhancer',['GlossEnhancer',['../d8/dcb/classHPLFPSDK_1_1Types.html#a3a196242769e9fb10d23ad1a3f123dd9',1,'HPLFPSDK::Types::GlossEnhancer()'],['../d9/d49/types_8h.html#ae9768ae429e6c634ab00a2455d5a0f76',1,'GlossEnhancer():&#160;types.h']]]
];
