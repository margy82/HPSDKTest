var searchData=
[
  ['metricdistance',['MetricDistance',['../d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html#ae81f78d9b06230202efc9a4f4b2efee7',1,'HPLFPSDK::Types::MetricDistance::MetricDistance()'],['../d4/dd5/structMetricDistance.html#ab8d582cd9ed5ffbd30d97bd70536385e',1,'MetricDistance::MetricDistance()']]],
  ['modifypapermode',['modifyPaperMode',['../d0/dbf/classHPLFPSDK_1_1IMediaManager.html#af55ee509a9daafcb149880cc45740de8',1,'HPLFPSDK::IMediaManager']]]
];
