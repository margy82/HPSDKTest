var searchData=
[
  ['hp_20lfp_20sdk_20library_20main_20interface_2e',['HP LFP SDK Library main interface.',['../df/de6/group__API__C__Methods.html',1,'']]],
  ['highspeed',['HighSpeed',['../d8/dcb/classHPLFPSDK_1_1Types.html#a64e6e2b7c7b90cc909b79e2cfab0097e',1,'HPLFPSDK::Types::HighSpeed()'],['../d9/d49/types_8h.html#a4c9aed4916b80ff44d210cca2df5081f',1,'HighSpeed():&#160;types.h']]],
  ['highspeed_5foff',['HIGHSPEED_OFF',['../d8/dcb/classHPLFPSDK_1_1Types.html#a64e6e2b7c7b90cc909b79e2cfab0097eadb91c3f296f40da597da8c160afd692e',1,'HPLFPSDK::Types::HIGHSPEED_OFF()'],['../d9/d49/types_8h.html#a4c9aed4916b80ff44d210cca2df5081fa56a6258ed5478025e773a6cd8cc0ad02',1,'HIGHSPEED_OFF():&#160;types.h']]],
  ['highspeed_5fon',['HIGHSPEED_ON',['../d8/dcb/classHPLFPSDK_1_1Types.html#a64e6e2b7c7b90cc909b79e2cfab0097eaaff1ba7ef5dcdf877dd0a18079b03a3b',1,'HPLFPSDK::Types::HIGHSPEED_ON()'],['../d9/d49/types_8h.html#a4c9aed4916b80ff44d210cca2df5081fa6e2c896aff92fefd6475fd7e442c1587',1,'HIGHSPEED_ON():&#160;types.h']]],
  ['hpguid',['HPGUID',['../da/def/ISolPacker_8h.html#ad64a5547551fda42bbbb5105c5226a5c',1,'ISolPacker.h']]],
  ['hplfpsdk',['HPLFPSDK',['../d0/d8c/namespaceHPLFPSDK.html',1,'']]],
  ['hplfpsdk_5fdeletebuffer',['hplfpsdk_deleteBuffer',['../df/de6/group__API__C__Methods.html#ga768a22264350c2f3a8b1d2b313679627',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fdiscardprinter',['hplfpsdk_discardPrinter',['../df/de6/group__API__C__Methods.html#ga601ef9509296e60bf6b076d5db295176',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetnetworkprinters',['hplfpsdk_getNetworkPrinters',['../df/de6/group__API__C__Methods.html#ga67eb368921d8bcad4ed2afa15b694bd6',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetnetworkprintersextended',['hplfpsdk_getNetworkPrintersExtended',['../df/de6/group__API__C__Methods.html#ga24f7826fb9348317c0481d391c27f0d7',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetnewprinter',['hplfpsdk_getNewPrinter',['../df/de6/group__API__C__Methods.html#ga2ef92a6554954b53f98d3a5710d66533',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetsupportedprintermodels',['hplfpsdk_getSupportedPrinterModels',['../df/de6/group__API__C__Methods.html#ga5e2bb01d1b4f84eb36705dadfef8a221',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetversion',['hplfpsdk_getVersion',['../df/de6/group__API__C__Methods.html#gae7705a865f3b92039a064650aceab3a6',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fguid',['HPLFPSDK_GUID',['../da/def/ISolPacker_8h.html#a200faf5b743644c4e40989bf80f39871',1,'ISolPacker.h']]],
  ['hplfpsdk_5finit',['hplfpsdk_init',['../df/de6/group__API__C__Methods.html#gac853ede1e83227e3b1486eebc6bc9134',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fisprintermodelsupported',['hplfpsdk_isPrinterModelSupported',['../df/de6/group__API__C__Methods.html#ga123e7d9e1abcb4f924d0a244061786e3',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fsetloglevel',['hplfpsdk_setLogLevel',['../df/de6/group__API__C__Methods.html#gab58e6808793b7406a26231176ee1b888',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fterminate',['hplfpsdk_terminate',['../df/de6/group__API__C__Methods.html#ga30e979736cafb91099c9431b590ad098',1,'IHplfpsdk.h']]],
  ['hplfpsdktypes_2eh',['HplfpsdkTypes.h',['../d5/db7/HplfpsdkTypes_8h.html',1,'']]],
  ['how_20to_20use_20the_20hp_20lfp_20sdk_20library_2e',['How to use the HP LFP SDK Library.',['../d8/d15/page_Use_SDK_Library.html',1,'']]]
];
