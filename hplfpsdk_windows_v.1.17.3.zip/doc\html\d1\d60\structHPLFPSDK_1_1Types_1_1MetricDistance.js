var structHPLFPSDK_1_1Types_1_1MetricDistance =
[
    [ "MetricDistance", "d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html#ae81f78d9b06230202efc9a4f4b2efee7", null ],
    [ "units", "d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html#a925acf5338a292f358130f6af62f893d", null ],
    [ "unitsPerInch", "d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html#a3fc953ec749bf79e7ebfa2bbfba96d97", null ]
];