var searchData=
[
  ['triggeradvancecalibration',['triggerAdvanceCalibration',['../d0/dbc/classHPLFPSDK_1_1IRemoteManager.html#aff3fa47c75a0fddc5ae4dafaf1c2cce8',1,'HPLFPSDK::IRemoteManager']]],
  ['triggercalibration',['triggerCalibration',['../d0/dbc/classHPLFPSDK_1_1IRemoteManager.html#a849e641c1cd22012655ba3caff0c8fff',1,'HPLFPSDK::IRemoteManager']]],
  ['triggerinkdensitycalibration',['triggerInkDensityCalibration',['../d0/dbc/classHPLFPSDK_1_1IRemoteManager.html#a7e23c198b79a204d40fa5f0c0f309467',1,'HPLFPSDK::IRemoteManager']]]
];
