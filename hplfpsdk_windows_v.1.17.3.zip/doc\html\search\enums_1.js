var searchData=
[
  ['calibrationdestinationtype',['CalibrationDestinationType',['../d8/dcb/classHPLFPSDK_1_1Types.html#a5e2c258b3b2ebacc83eb696b9f599057',1,'HPLFPSDK::Types']]],
  ['calibrationtype',['CalibrationType',['../d8/dcb/classHPLFPSDK_1_1Types.html#a74a27be223b0c38e53af799c4d4252a7',1,'HPLFPSDK::Types']]],
  ['colormode',['ColorMode',['../d8/dcb/classHPLFPSDK_1_1Types.html#aa288b5e87f4a7388ba9efa735331cae4',1,'HPLFPSDK::Types::ColorMode()'],['../d9/d49/types_8h.html#a5b418087cdcc424fed5e8ea1e4b5c280',1,'ColorMode():&#160;types.h']]],
  ['colorspace',['ColorSpace',['../d8/dcb/classHPLFPSDK_1_1Types.html#a3d6269431e410b3be99582b49745fde5',1,'HPLFPSDK::Types::ColorSpace()'],['../d9/d49/types_8h.html#a15ad986921d86a55ab5c73a00a82053b',1,'ColorSpace():&#160;types.h']]],
  ['contentalignment',['ContentAlignment',['../d8/dcb/classHPLFPSDK_1_1Types.html#ad776a696031ff6484b616b16f4ac6ba5',1,'HPLFPSDK::Types::ContentAlignment()'],['../d9/d49/types_8h.html#ab2cab5df032095fce8f33acdc906cf33',1,'ContentAlignment():&#160;types.h']]],
  ['cutter',['Cutter',['../d8/dcb/classHPLFPSDK_1_1Types.html#adde406bbee2a71ea5f7ebcdec30b8c76',1,'HPLFPSDK::Types::Cutter()'],['../d9/d49/types_8h.html#a2aaa3b9f9116abac4fbbac87073e90a2',1,'Cutter():&#160;types.h']]]
];
