var searchData=
[
  ['ycutter_5fdisabled',['YCUTTER_DISABLED',['../d8/dcb/classHPLFPSDK_1_1Types.html#a92861490b2b834bd131025e61dcbd60ca52c3b940742dc44265d7d5faa6ca110f',1,'HPLFPSDK::Types::YCUTTER_DISABLED()'],['../d9/d49/types_8h.html#a66f372cc5eea0a20f0d45190ee44ce38aa041b1fd97de70d6110488e75752843c',1,'YCUTTER_DISABLED():&#160;types.h']]],
  ['ycutter_5fenabled',['YCUTTER_ENABLED',['../d8/dcb/classHPLFPSDK_1_1Types.html#a92861490b2b834bd131025e61dcbd60ca55bbed6b683ea7671e71233d74b83193',1,'HPLFPSDK::Types::YCUTTER_ENABLED()'],['../d9/d49/types_8h.html#a66f372cc5eea0a20f0d45190ee44ce38ad8dcd170489c138c206554520c1cbd97',1,'YCUTTER_ENABLED():&#160;types.h']]]
];
