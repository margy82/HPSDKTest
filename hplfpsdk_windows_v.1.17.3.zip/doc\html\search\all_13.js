var searchData=
[
  ['time_5fhi_5fand_5fversion',['time_hi_and_version',['../d0/d97/struct__HPLFPSDK__GUID.html#a860f0be418c7745047c4fe5a94a323da',1,'_HPLFPSDK_GUID']]],
  ['time_5flow',['time_low',['../d0/d97/struct__HPLFPSDK__GUID.html#a6a07abc39afe23d0c598c6b10ab5471d',1,'_HPLFPSDK_GUID']]],
  ['time_5fmid',['time_mid',['../d0/d97/struct__HPLFPSDK__GUID.html#a236af0b0c05c59b797c959d5804b6e14',1,'_HPLFPSDK_GUID']]],
  ['transmissionstatuscallback',['transmissionStatusCallback',['../d3/d96/classHPLFPSDK_1_1IJobPacker.html#a253500680c9e24e2d60d33562a289bf3',1,'HPLFPSDK::IJobPacker']]],
  ['triggeradvancecalibration',['triggerAdvanceCalibration',['../d0/dbc/classHPLFPSDK_1_1IRemoteManager.html#aff3fa47c75a0fddc5ae4dafaf1c2cce8',1,'HPLFPSDK::IRemoteManager']]],
  ['triggercalibration',['triggerCalibration',['../d0/dbc/classHPLFPSDK_1_1IRemoteManager.html#a849e641c1cd22012655ba3caff0c8fff',1,'HPLFPSDK::IRemoteManager']]],
  ['triggerinkdensitycalibration',['triggerInkDensityCalibration',['../d0/dbc/classHPLFPSDK_1_1IRemoteManager.html#a7e23c198b79a204d40fa5f0c0f309467',1,'HPLFPSDK::IRemoteManager']]],
  ['types',['Types',['../d8/dcb/classHPLFPSDK_1_1Types.html',1,'HPLFPSDK']]],
  ['types_2eh',['types.h',['../d9/d49/types_8h.html',1,'']]]
];
