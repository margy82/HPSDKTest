var searchData=
[
  ['job_5flanguage_5fpcl3gui',['JOB_LANGUAGE_PCL3GUI',['../d8/dcb/classHPLFPSDK_1_1Types.html#a885eb56f5a87e17c1da55d98c5a3296ca3e32e10cf8ca393e054abc4698d995dd',1,'HPLFPSDK::Types']]],
  ['job_5flanguage_5frstream',['JOB_LANGUAGE_RSTREAM',['../d8/dcb/classHPLFPSDK_1_1Types.html#a885eb56f5a87e17c1da55d98c5a3296cad660c40045318d7a62eb827470c44834',1,'HPLFPSDK::Types']]],
  ['job_5flanguage_5funknown',['JOB_LANGUAGE_UNKNOWN',['../d8/dcb/classHPLFPSDK_1_1Types.html#a885eb56f5a87e17c1da55d98c5a3296cabd3d98ee7d006ef54bcefac72a0d9d16',1,'HPLFPSDK::Types']]],
  ['jobcollate_5foff',['JOBCOLLATE_OFF',['../d8/dcb/classHPLFPSDK_1_1Types.html#a9efb9a35af03fcdaaa46f33040d107f8a17cfa7f5e65f166934514e1b4357c71e',1,'HPLFPSDK::Types::JOBCOLLATE_OFF()'],['../d9/d49/types_8h.html#a5d5ee643a16dea3201638b6aa001657aa578e024d6214e63f08cd4ce02172aa88',1,'JOBCOLLATE_OFF():&#160;types.h']]],
  ['jobcollate_5fon',['JOBCOLLATE_ON',['../d8/dcb/classHPLFPSDK_1_1Types.html#a9efb9a35af03fcdaaa46f33040d107f8afbe7f62700297a941d1291b7ab65aace',1,'HPLFPSDK::Types::JOBCOLLATE_ON()'],['../d9/d49/types_8h.html#a5d5ee643a16dea3201638b6aa001657aa1b2d0e1d8856c679738b398edbc33dd5',1,'JOBCOLLATE_ON():&#160;types.h']]],
  ['jobpacker_5ftype_5fnone',['JOBPACKER_TYPE_NONE',['../d3/d96/classHPLFPSDK_1_1IJobPacker.html#a67ddc0127767e7083ed49b237b941383a130791ec3f28b1ec7bbe2e78661efe0d',1,'HPLFPSDK::IJobPacker']]]
];
