var searchData=
[
  ['glossenhancer_5ffullpage',['GLOSSENHANCER_FULLPAGE',['../d8/dcb/classHPLFPSDK_1_1Types.html#a3a196242769e9fb10d23ad1a3f123dd9ac9c27f6b87950ebad64a740415c5d6d5',1,'HPLFPSDK::Types::GLOSSENHANCER_FULLPAGE()'],['../d9/d49/types_8h.html#ae9768ae429e6c634ab00a2455d5a0f76aeeefc1f04f1b343fe291a10985aed0f4',1,'GLOSSENHANCER_FULLPAGE():&#160;types.h']]],
  ['glossenhancer_5finkedarea',['GLOSSENHANCER_INKEDAREA',['../d8/dcb/classHPLFPSDK_1_1Types.html#a3a196242769e9fb10d23ad1a3f123dd9acbd7b98fe2f74654975a4d8532039d56',1,'HPLFPSDK::Types::GLOSSENHANCER_INKEDAREA()'],['../d9/d49/types_8h.html#ae9768ae429e6c634ab00a2455d5a0f76a7367c75e4935e61de2c270a6c19a99d0',1,'GLOSSENHANCER_INKEDAREA():&#160;types.h']]],
  ['glossenhancer_5foff',['GLOSSENHANCER_OFF',['../d8/dcb/classHPLFPSDK_1_1Types.html#a3a196242769e9fb10d23ad1a3f123dd9a662dc0f7f4e8959bc6a4ffc020b40436',1,'HPLFPSDK::Types::GLOSSENHANCER_OFF()'],['../d9/d49/types_8h.html#ae9768ae429e6c634ab00a2455d5a0f76a9723b03a66285047b2f498be148c1bf7',1,'GLOSSENHANCER_OFF():&#160;types.h']]]
];
