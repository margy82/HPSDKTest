var searchData=
[
  ['verticalcontentalignment',['VerticalContentAlignment',['../d8/dcb/classHPLFPSDK_1_1Types.html#a0401c045564c9517b51593eb7160e1e7',1,'HPLFPSDK::Types::VerticalContentAlignment()'],['../d9/d49/types_8h.html#ad59e2af5778a4c0058c60929f56b0273',1,'VerticalContentAlignment():&#160;types.h']]]
];
