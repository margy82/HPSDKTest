////////////////////////////////////////////////////////////////////////////
/**
* @file  getMediaInformationCounter.cpp
* @author Julia Herrero Fernandez julia.herrero.fernandez@hp.com
* @date   Fri Dec  16 11:27:33 CEST 2016
* @brief  C++ CodeSample.
* Sample Code that demostrates the usage of getMediaInformationCounter call of media manager web service.
*
* getMediaInformationCounter returns an array of chars with the counter list for all media.
* This allocated memory shall be deleted using hplfpsdk_deleteBuffer() interface.
*
* In order to make it clearer this code does not include proper error checking
* (some asserts are include instead) nor user iteraction.
*
* @par &copy; Copyright Hewlett-Packard Company, 2000-2016.
* All rights reserved. Copying or other reproduction of this program except
* for archival purposes is prohibited without written consent of
* Hewlett-Packard Company.
*/
////////////////////////////////////////////////////////////////////////////


#include "getMediaInformationCounter.h"

#include <assert.h>
#include <string>

int HPLFPSDK_SAMPLES::getMediaInformationCounter(HPLFPSDK::IDevice * device)
{
    //GETTING MEDIA MANAGER OBJECT
    HPLFPSDK::IMediaManager *mediaManager_ = device->getMediaManager();
    HPLFPSDK::Types::Result result = HPLFPSDK::Types::RESULT_OK;
    char *mediaInformationCounter = nullptr;
    size_t longLength = 0;
    //CALL TO GETMEDIAINFORMATIONCOUNTER
    result = mediaManager_->getMediaInformationCounter(&mediaInformationCounter, longLength);
    if (result == HPLFPSDK::Types::RESULT_OK)
    {
        //PRINT TO SCREEN ALL MEDIAINFORMATIONCOUNTER
        std::cout << mediaInformationCounter << std::endl;
        //DELETE BUFFER
        hplfpsdk_deleteBuffer(&mediaInformationCounter);
    }
    else
    {
        std::cout << "Error: " << result << std::endl;
    }

    return 0;
}
