var searchData=
[
  ['whitedensity',['WhiteDensity',['../d8/dcb/classHPLFPSDK_1_1Types.html#aebf4f08f103b1d238f3bd0e9824d450f',1,'HPLFPSDK::Types::WhiteDensity()'],['../d9/d49/types_8h.html#a9534fda40e162fb8435eb4ecb7d155ed',1,'WhiteDensity():&#160;types.h']]],
  ['whitemode',['WhiteMode',['../d8/dcb/classHPLFPSDK_1_1Types.html#a76344a58ea34880aaa17d2141e5485ba',1,'HPLFPSDK::Types::WhiteMode()'],['../d9/d49/types_8h.html#a3a36f60cea410d65b02c59b97ce7a7ea',1,'WhiteMode():&#160;types.h']]],
  ['whiteshrink',['WhiteShrink',['../d8/dcb/classHPLFPSDK_1_1Types.html#a6826ad9c1694e8f4bc25d1c7fed5ba6a',1,'HPLFPSDK::Types::WhiteShrink()'],['../d9/d49/types_8h.html#a0d3e188836a97ca7ef4622a6bf9ff2bb',1,'WhiteShrink():&#160;types.h']]]
];
