var searchData=
[
  ['hplfpsdk_5fdeletebuffer',['hplfpsdk_deleteBuffer',['../df/de6/group__API__C__Methods.html#ga768a22264350c2f3a8b1d2b313679627',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fdiscardprinter',['hplfpsdk_discardPrinter',['../df/de6/group__API__C__Methods.html#ga601ef9509296e60bf6b076d5db295176',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetnetworkprinters',['hplfpsdk_getNetworkPrinters',['../df/de6/group__API__C__Methods.html#ga67eb368921d8bcad4ed2afa15b694bd6',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetnetworkprintersextended',['hplfpsdk_getNetworkPrintersExtended',['../df/de6/group__API__C__Methods.html#ga24f7826fb9348317c0481d391c27f0d7',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetnewprinter',['hplfpsdk_getNewPrinter',['../df/de6/group__API__C__Methods.html#ga2ef92a6554954b53f98d3a5710d66533',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetsupportedprintermodels',['hplfpsdk_getSupportedPrinterModels',['../df/de6/group__API__C__Methods.html#ga5e2bb01d1b4f84eb36705dadfef8a221',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fgetversion',['hplfpsdk_getVersion',['../df/de6/group__API__C__Methods.html#gae7705a865f3b92039a064650aceab3a6',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5finit',['hplfpsdk_init',['../df/de6/group__API__C__Methods.html#gac853ede1e83227e3b1486eebc6bc9134',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fisprintermodelsupported',['hplfpsdk_isPrinterModelSupported',['../df/de6/group__API__C__Methods.html#ga123e7d9e1abcb4f924d0a244061786e3',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fsetloglevel',['hplfpsdk_setLogLevel',['../df/de6/group__API__C__Methods.html#gab58e6808793b7406a26231176ee1b888',1,'IHplfpsdk.h']]],
  ['hplfpsdk_5fterminate',['hplfpsdk_terminate',['../df/de6/group__API__C__Methods.html#ga30e979736cafb91099c9431b590ad098',1,'IHplfpsdk.h']]]
];
