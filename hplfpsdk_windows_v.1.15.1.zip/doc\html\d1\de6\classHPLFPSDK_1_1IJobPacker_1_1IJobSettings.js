var classHPLFPSDK_1_1IJobPacker_1_1IJobSettings =
[
    [ "~IJobSettings", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a7a33e12a9b07bb7f19b9d1c32ddc362d", null ],
    [ "dumpToChar", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a8fd2d4f4cc319879c237c7b5170f80f6", null ],
    [ "setAccountId", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a1a230ad62366000e8ec03e35a995d0dc", null ],
    [ "setApplicationName", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a281c2d32312efb00114ce4cd1e65acd2", null ],
    [ "setApplicationUuid", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a0072626ade0e9313333047201f98ddb2", null ],
    [ "setApplicationVersion", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#aed41ba51284bf6b7b2aa1af6ed1446f3", null ],
    [ "setAttendedMode", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#aa860bbd7dac997a4952bcb819fa199f7", null ],
    [ "setCutter", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#ae442c20c62a9bbaf9c7d04a4b9982c58", null ],
    [ "setDualSideOrder", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#ac1b0ee8fb9b8263bd1bfed8ddee81d54", null ],
    [ "setFMBillable", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#ad4ce3e44ad2d475dbd8ad806714807a1", null ],
    [ "setFMToken", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#af2956025e5fda60db49783fef3474673", null ],
    [ "setJobCollate", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#ad86d6f25529fa2decb88b0a744d11361", null ],
    [ "setJobCopies", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#aad748cc93d266228b679cb4df6218579", null ],
    [ "setJobName", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a98e06f5a8e5c2314a9a2b2f7dbb28e66", null ],
    [ "setJobUuid", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a129c56f9527b353065af6dbc3825b281", null ],
    [ "setPartnerId", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a68732ed20fcbf56ce51020550e45ee71", null ],
    [ "setPrintingOrder", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a063ff0bcbf232b8e4323cc6efccfadc3", null ],
    [ "setProjectId", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a943cb8804e95089d5e327e43e3d75170", null ],
    [ "setTimeStamp", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#ae1c0087a637fa590d3870c7893903b71", null ],
    [ "setUserName", "d1/de6/classHPLFPSDK_1_1IJobPacker_1_1IJobSettings.html#a0a4e0a122dac734ecade92ad72ac6642", null ]
];