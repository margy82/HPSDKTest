//////////////////////////////////////////////////////////////////////////////
/**
* @file  EventingSample.h
* @author Julia Herrero Fernandez julia.herrero.fernandez@hp.com
* @date   Wed, 22 Mar 2017 11:38:03 +0100
* @brief  C++ CodeSample.
* Sample Code that demostrates the usage of eventing inside sdk
*
* In order to make it clearer this code does not include proper error checking
* (some asserts are include instead) nor user iteraction.
*
* @par &copy; Copyright Hewlett-Packard Company, 2000-2016.
* All rights reserved. Copying or other reproduction of this program except
* for archival purposes is prohibited without written consent of
* Hewlett-Packard Company.
*/
//////////////////////////////////////////////////////////////////////////////
#include "EventingSample.h"

#include <assert.h>
#include <string>

void HPLFPSDK_SAMPLES::onChangeCallback(HPLFPSDK::IInfoManager::InfoEventType type, void *userData, uint32_t subscriptionId, const char *newXmlValue, int xmlLength)
{
    std::cout << "EVENT RECEIVED" << std::endl;
    std::cout << "Type: " << type << std::endl;
    std::cout << "SubscriptionId: " << subscriptionId << std::endl;
    std::cout << "Length: " << xmlLength << std::endl;
    std::cout << "Value: " << newXmlValue << std::endl;
    std::cout << "END EVENT" << std::endl;
}

int HPLFPSDK_SAMPLES::eventingSample(HPLFPSDK::IDevice * printer)
{

    HPLFPSDK::Types::Result result = HPLFPSDK::Types::RESULT_OK;
    static uint32_t inkSystemSubscriptionId = 0;
    //GETTING INFO MANAGER OBJECT
    HPLFPSDK::IInfoManager *infoManager_ = printer->getInfoManager();
    //SUBSCRIPTION TO INK SYSTEM STATUS (This call internally subscribes to each ink slot and group alert)
    result = infoManager_->subscribeToInkSystemStatus(HPLFPSDK_SAMPLES::onChangeCallback, NULL, &inkSystemSubscriptionId);
    if(result == HPLFPSDK::Types::RESULT_OK)
    {
        std::cout << " subscribeToInkSystemStatus OK";
    }
    else
    {
         std::cout << "ERROR in subscribeToInkSystemStatus";
    }
    //WHEN DISCARDING THE DEVICE THE LIBRARY UNSUBSCRIBE TO ALL EVENTS
    return 0;
}
