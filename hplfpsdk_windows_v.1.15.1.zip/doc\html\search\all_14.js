var searchData=
[
  ['uuid_20format_2e',['UUID format.',['../dd/dba/page_appendix_UUID_format.html',1,'']]],
  ['usage_20manager_20object',['Usage Manager Object',['../d7/ddc/page_usageManager.html',1,'']]],
  ['unidirectional',['Unidirectional',['../d8/dcb/classHPLFPSDK_1_1Types.html#a5727c232bd7bc5a9f809b0016564cf16',1,'HPLFPSDK::Types::Unidirectional()'],['../d9/d49/types_8h.html#a5d21690228b6799fa053bf092c79c02b',1,'Unidirectional():&#160;types.h']]],
  ['unidirectional_5foff',['UNIDIRECTIONAL_OFF',['../d8/dcb/classHPLFPSDK_1_1Types.html#a5727c232bd7bc5a9f809b0016564cf16a94fe2a8c96882a6e5c7759b3cb23558e',1,'HPLFPSDK::Types::UNIDIRECTIONAL_OFF()'],['../d9/d49/types_8h.html#a5d21690228b6799fa053bf092c79c02ba735a4678860e9f51f5db702770c6bf2a',1,'UNIDIRECTIONAL_OFF():&#160;types.h']]],
  ['unidirectional_5fon',['UNIDIRECTIONAL_ON',['../d8/dcb/classHPLFPSDK_1_1Types.html#a5727c232bd7bc5a9f809b0016564cf16a5527806652c5050b22411f1024224910',1,'HPLFPSDK::Types::UNIDIRECTIONAL_ON()'],['../d9/d49/types_8h.html#a5d21690228b6799fa053bf092c79c02ba526e899fad4a6d97234d926d914ec423',1,'UNIDIRECTIONAL_ON():&#160;types.h']]],
  ['units',['units',['../d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html#a925acf5338a292f358130f6af62f893d',1,'HPLFPSDK::Types::MetricDistance::units()'],['../d4/dd5/structMetricDistance.html#a36ea3b8085aa53ef13fc2e8f0c3ae717',1,'MetricDistance::units()']]],
  ['unitsperinch',['unitsPerInch',['../d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html#a3fc953ec749bf79e7ebfa2bbfba96d97',1,'HPLFPSDK::Types::MetricDistance::unitsPerInch()'],['../d4/dd5/structMetricDistance.html#a32900f9e6a4fb44c4d95cf5581288e06',1,'MetricDistance::unitsPerInch()']]],
  ['unsubscribe',['unsubscribe',['../d0/dbf/classHPLFPSDK_1_1IMediaManager.html#aacbaed82452dc5e58bac2262d9699fe7',1,'HPLFPSDK::IMediaManager::unsubscribe()'],['../db/da5/classHPLFPSDK_1_1IInfoManager.html#a511f811152c3cc412ec887899a40c18a',1,'HPLFPSDK::IInfoManager::unsubscribe()']]],
  ['uploadmediapreset',['uploadMediaPreset',['../d0/dbf/classHPLFPSDK_1_1IMediaManager.html#a239f46a44e42ca0ed79d2e8cdebec956',1,'HPLFPSDK::IMediaManager']]],
  ['usesdklibrary_2edox',['UseSDKLibrary.dox',['../d0/d0a/UseSDKLibrary_8dox.html',1,'']]]
];
