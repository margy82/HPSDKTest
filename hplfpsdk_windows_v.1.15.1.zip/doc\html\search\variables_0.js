var searchData=
[
  ['buffer',['buffer',['../d5/d35/classHPLFPSDK_1_1IJobPacker_1_1RS__buffer.html#a0b580d9144014d55afad6a823f7cbe88',1,'HPLFPSDK::IJobPacker::RS_buffer']]],
  ['buffer_5f',['buffer_',['../df/dcf/classHPLFPSDK_1_1IJobPacker_1_1Preview.html#aac27da80e78423a423b935da5dd5bec4',1,'HPLFPSDK::IJobPacker::Preview']]]
];
