var searchData=
[
  ['highspeed',['HighSpeed',['../d8/dcb/classHPLFPSDK_1_1Types.html#a64e6e2b7c7b90cc909b79e2cfab0097e',1,'HPLFPSDK::Types::HighSpeed()'],['../d9/d49/types_8h.html#a4c9aed4916b80ff44d210cca2df5081f',1,'HighSpeed():&#160;types.h']]]
];
