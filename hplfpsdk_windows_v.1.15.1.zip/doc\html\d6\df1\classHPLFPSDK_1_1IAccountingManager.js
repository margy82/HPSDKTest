var classHPLFPSDK_1_1IAccountingManager =
[
    [ "~IAccountingManager", "d6/df1/classHPLFPSDK_1_1IAccountingManager.html#a18fcc8c6b353ae515d02c7db68609184", null ],
    [ "getJobAccountingInfo", "d6/df1/classHPLFPSDK_1_1IAccountingManager.html#a66cb0dde9d17a67d0fc8a054a8bc5576", null ],
    [ "getJobAccountingInfoByDate", "d6/df1/classHPLFPSDK_1_1IAccountingManager.html#affa58aef4706d4d284265b92f69b654d", null ],
    [ "getJobAccountingInfoByNumber", "d6/df1/classHPLFPSDK_1_1IAccountingManager.html#ac427410d37ad2556f7e82ab3ce3f05d4", null ]
];