var searchData=
[
  ['uuid_20format_2e',['UUID format.',['../dd/dba/page_appendix_UUID_format.html',1,'']]],
  ['usage_20manager_20object',['Usage Manager Object',['../d7/ddc/page_usageManager.html',1,'']]]
];
