var searchData=
[
  ['onasyncquerycallback',['onAsyncQueryCallback',['../d0/d8c/namespaceHPLFPSDK.html#a9c3b8a600d72990921b5f39ca1272340',1,'HPLFPSDK']]],
  ['onchangecallback',['onChangeCallback',['../d0/dbf/classHPLFPSDK_1_1IMediaManager.html#afffe83ffbdb8c566ed1a26b05bbf948b',1,'HPLFPSDK::IMediaManager::onChangeCallback()'],['../db/da5/classHPLFPSDK_1_1IInfoManager.html#a5d5fcaff63ef560169e4034307f4eb23',1,'HPLFPSDK::IInfoManager::onChangeCallback()']]],
  ['onrasterrowcallback',['onRasterRowCallback',['../d0/d8c/namespaceHPLFPSDK.html#ac6181a50a91af7282383b74bfd282ee9',1,'HPLFPSDK']]],
  ['onreceivedatacallback',['onReceiveDataCallback',['../df/d4c/classHPLFPSDK_1_1IScanPacker.html#ab8a7167d38f0b36ace1bf78afd9fe87f',1,'HPLFPSDK::IScanPacker']]],
  ['overcoat',['Overcoat',['../d8/dcb/classHPLFPSDK_1_1Types.html#aa1b1e5608ae4f8dacacbca86d4be3a6b',1,'HPLFPSDK::Types::Overcoat()'],['../d9/d49/types_8h.html#a282236f4ec55f59c5dd6ac4def166a18',1,'Overcoat():&#160;types.h']]],
  ['overcoat_5foff',['OVERCOAT_OFF',['../d8/dcb/classHPLFPSDK_1_1Types.html#aa1b1e5608ae4f8dacacbca86d4be3a6ba48858da9ac29e2120ca034dc4c1e3c20',1,'HPLFPSDK::Types::OVERCOAT_OFF()'],['../d9/d49/types_8h.html#a282236f4ec55f59c5dd6ac4def166a18a2622ed4336782700a00e7f61b3ae73ab',1,'OVERCOAT_OFF():&#160;types.h']]],
  ['overcoat_5fon',['OVERCOAT_ON',['../d8/dcb/classHPLFPSDK_1_1Types.html#aa1b1e5608ae4f8dacacbca86d4be3a6ba52151b2e016dfe53ead6c9a8a10c1665',1,'HPLFPSDK::Types::OVERCOAT_ON()'],['../d9/d49/types_8h.html#a282236f4ec55f59c5dd6ac4def166a18a30c8ee986f9bc4514765d33af78f015d',1,'OVERCOAT_ON():&#160;types.h']]]
];
