var searchData=
[
  ['newjob',['newJob',['../d3/d96/classHPLFPSDK_1_1IJobPacker.html#a85c040fd59cdb6bbd4c120083cf7d6b0',1,'HPLFPSDK::IJobPacker::newJob()'],['../d6/dc7/classHPLFPSDK_1_1ISolPacker.html#a051358ec33390fa82d266b206ac3cd97',1,'HPLFPSDK::ISolPacker::newJob(IJobSettings *settings, ISolPacker::ISolMemoryHandler *mhdl, transmissionStatusCallback callback, void *userData)=0'],['../d6/dc7/classHPLFPSDK_1_1ISolPacker.html#a010e5654ca6b75cb5aef0793b9641064',1,'HPLFPSDK::ISolPacker::newJob(IJobSettings *settings, IMemoryHandler *mhdl, transmissionStatusCallback callback, void *userData)']]]
];
