var searchData=
[
  ['units',['units',['../d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html#a925acf5338a292f358130f6af62f893d',1,'HPLFPSDK::Types::MetricDistance::units()'],['../d4/dd5/structMetricDistance.html#a36ea3b8085aa53ef13fc2e8f0c3ae717',1,'MetricDistance::units()']]],
  ['unitsperinch',['unitsPerInch',['../d1/d60/structHPLFPSDK_1_1Types_1_1MetricDistance.html#a3fc953ec749bf79e7ebfa2bbfba96d97',1,'HPLFPSDK::Types::MetricDistance::unitsPerInch()'],['../d4/dd5/structMetricDistance.html#a32900f9e6a4fb44c4d95cf5581288e06',1,'MetricDistance::unitsPerInch()']]]
];
