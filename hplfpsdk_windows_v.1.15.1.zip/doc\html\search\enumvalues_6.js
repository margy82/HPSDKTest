var searchData=
[
  ['highspeed_5foff',['HIGHSPEED_OFF',['../d8/dcb/classHPLFPSDK_1_1Types.html#a64e6e2b7c7b90cc909b79e2cfab0097eadb91c3f296f40da597da8c160afd692e',1,'HPLFPSDK::Types::HIGHSPEED_OFF()'],['../d9/d49/types_8h.html#a4c9aed4916b80ff44d210cca2df5081fa56a6258ed5478025e773a6cd8cc0ad02',1,'HIGHSPEED_OFF():&#160;types.h']]],
  ['highspeed_5fon',['HIGHSPEED_ON',['../d8/dcb/classHPLFPSDK_1_1Types.html#a64e6e2b7c7b90cc909b79e2cfab0097eaaff1ba7ef5dcdf877dd0a18079b03a3b',1,'HPLFPSDK::Types::HIGHSPEED_ON()'],['../d9/d49/types_8h.html#a4c9aed4916b80ff44d210cca2df5081fa6e2c896aff92fefd6475fd7e442c1587',1,'HIGHSPEED_ON():&#160;types.h']]]
];
