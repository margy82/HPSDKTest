var namespaceHPLFPSDK =
[
    [ "IAccountingManager", "d6/df1/classHPLFPSDK_1_1IAccountingManager.html", "d6/df1/classHPLFPSDK_1_1IAccountingManager" ],
    [ "IDevice", "d0/d0a/classHPLFPSDK_1_1IDevice.html", "d0/d0a/classHPLFPSDK_1_1IDevice" ],
    [ "IInfoManager", "db/da5/classHPLFPSDK_1_1IInfoManager.html", "db/da5/classHPLFPSDK_1_1IInfoManager" ],
    [ "IJobPacker", "d3/d96/classHPLFPSDK_1_1IJobPacker.html", "d3/d96/classHPLFPSDK_1_1IJobPacker" ],
    [ "IMediaManager", "d0/dbf/classHPLFPSDK_1_1IMediaManager.html", "d0/dbf/classHPLFPSDK_1_1IMediaManager" ],
    [ "IRemoteManager", "d0/dbc/classHPLFPSDK_1_1IRemoteManager.html", "d0/dbc/classHPLFPSDK_1_1IRemoteManager" ],
    [ "IScanPacker", "df/d4c/classHPLFPSDK_1_1IScanPacker.html", "df/d4c/classHPLFPSDK_1_1IScanPacker" ],
    [ "ISolPacker", "d6/dc7/classHPLFPSDK_1_1ISolPacker.html", "d6/dc7/classHPLFPSDK_1_1ISolPacker" ],
    [ "IUsageManager", "d5/d19/classHPLFPSDK_1_1IUsageManager.html", "d5/d19/classHPLFPSDK_1_1IUsageManager" ],
    [ "Types", "d8/dcb/classHPLFPSDK_1_1Types.html", "d8/dcb/classHPLFPSDK_1_1Types" ]
];