var searchData=
[
  ['unsubscribe',['unsubscribe',['../d0/dbf/classHPLFPSDK_1_1IMediaManager.html#aacbaed82452dc5e58bac2262d9699fe7',1,'HPLFPSDK::IMediaManager::unsubscribe()'],['../db/da5/classHPLFPSDK_1_1IInfoManager.html#a511f811152c3cc412ec887899a40c18a',1,'HPLFPSDK::IInfoManager::unsubscribe()']]],
  ['uploadmediapreset',['uploadMediaPreset',['../d0/dbf/classHPLFPSDK_1_1IMediaManager.html#a239f46a44e42ca0ed79d2e8cdebec956',1,'HPLFPSDK::IMediaManager']]]
];
