var classHPLFPSDK_1_1IUsageManager =
[
    [ "~IUsageManager", "d5/d19/classHPLFPSDK_1_1IUsageManager.html#a050b358a595271ed9a4ccc15ede95c6e", null ],
    [ "getPrinterUsageInfo", "d5/d19/classHPLFPSDK_1_1IUsageManager.html#a233bc02fb6474c5587d35ad8b0648b20", null ]
];