//////////////////////////////////////////////////////////////////////////////
/**
* @file  getSupportedPrintModes.cpp
* @author Julia Herrero Fernandez julia.herrero.fernandez@hp.com
* @date   Fri Dec  16 11:27:33 CEST 2016
* @brief  C++ CodeSample.
* Sample Code that demostrates the usage of getSupportedPrintModes call of Media Manager Web Service.
*
* getSupportedPrintModes returns an array of chars with the supported printmodes information.
* getSupportedPrintModesmediaKey media ID used to filter the supported printmodes associated to the media ID.
* This allocated memory shall be deleted using hplfpsdk_deleteBuffer() interface.
*
* In order to make it clearer this code does not include proper error checking
* (some asserts are include instead) nor user iteraction.
*
* @par &copy; Copyright Hewlett-Packard Company, 2000-2016.
* All rights reserved. Copying or other reproduction of this program except
* for archival purposes is prohibited without written consent of
* Hewlett-Packard Company.
*/
////////////////////////////////////////////////////////////////////////////////

#include "getSupportedPrintmodes.h"

#include <assert.h>

int HPLFPSDK_SAMPLES::getSupportedPrintmodes(HPLFPSDK::IDevice * device, std::string mediaID)
{
    //GETTING MEDIA MANAGER OBJECT
    HPLFPSDK::IMediaManager *mediaManager_ = device->getMediaManager();
    HPLFPSDK::Types::Result result = HPLFPSDK::Types::RESULT_OK;
    size_t longLength = 0;
    char *supportedPrintmodes = NULL;
    //Calls to getSupportedPrintModes API, the mediaID is mandatory.
    result = mediaManager_->getSupportedPrintmodes(mediaID.c_str(), &supportedPrintmodes, longLength);
    assert(result == HPLFPSDK::Types::RESULT_OK);
    //PRINT TO SCREEN ALL SUPPORTEDPRINTMODES OF EVERY MEDIUM
    std::cout << supportedPrintmodes;
    //DELETE BUFFER
    hplfpsdk_deleteBuffer(&supportedPrintmodes);

    return 0;
}
