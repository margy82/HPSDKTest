////////////////////////////////////////////////////////////////////////////
/**
* @file  deletePrintJobSample.cpp
* @author Julia Herrero Fernandez julia.herrero.fernandez@hp.com
* @date   Fri Dec  16 11:27:33 CEST 2016
* @brief  C++ CodeSample.
* Sample Code that demostrates the usage of deletePrintJob call of remote manager web service
*
* deletePrintJob is used to delete a job from the Job Queue.
* Using this API we can delete only the job identified by job UUID.
*
* In order to make it clearer this code does not include proper error checking
* (some asserts are include instead) nor user iteraction.
*
*
* @par &copy; Copyright Hewlett-Packard Company, 2000-2016.
* All rights reserved. Copying or other reproduction of this program except
* for archival purposes is prohibited without written consent of
* Hewlett-Packard Company.
*/
//////////////////////////////////////////////////////////////////////////////

#include "deletePrintJobSample.h"

#include <assert.h>
#include <string>

int HPLFPSDK_SAMPLES::deletePrintJobSample(HPLFPSDK::IDevice * printer)
{
    
    HPLFPSDK::Types::Result result = HPLFPSDK::Types::RESULT_OK;

    //GETTING REMOTE MANAGER OBJECT
    HPLFPSDK::IRemoteManager *remoteManager_ = printer->getRemoteManager();
    char *jobStatusListXML = NULL;
    size_t longLength = 0;
    //CALL GET JOB STATUS TO GET THE JOBUUID OF ONE JOB
    result = remoteManager_->getJobStatusList(&jobStatusListXML, longLength);
    assert(result == HPLFPSDK::Types::RESULT_OK);
    char *jobId = NULL;
    if (jobStatusListXML)
    {
        //GETTING LAST JOB ID FROM JOBSTATUSLISTXML
        std::string tempJobId = jobStatusListXML;
        size_t pos = tempJobId.rfind("JobUUID=\"") + 9;
        size_t length = tempJobId.find("\"", pos) - pos;
        tempJobId = tempJobId.substr(pos, length);
        jobId = new char[length + 1];
        memcpy(jobId, tempJobId.c_str(), length + 1);
        //DELETE BUFFER
        hplfpsdk_deleteBuffer(&jobStatusListXML);
    }
    //DELETE THAT JOBID
    result = remoteManager_->deletePrintJob(jobId);
    assert(result == HPLFPSDK::Types::RESULT_OK);

    return 0;
}
