var structMetricDistance =
[
    [ "MetricDistance", "d4/dd5/structMetricDistance.html#ab8d582cd9ed5ffbd30d97bd70536385e", null ],
    [ "units", "d4/dd5/structMetricDistance.html#a36ea3b8085aa53ef13fc2e8f0c3ae717", null ],
    [ "unitsPerInch", "d4/dd5/structMetricDistance.html#a32900f9e6a4fb44c4d95cf5581288e06", null ]
];