var searchData=
[
  ['initializecolorchart',['initializeColorChart',['../d6/dc7/classHPLFPSDK_1_1ISolPacker.html#a92ef728b1e28f8836c60e60edfea56a4',1,'HPLFPSDK::ISolPacker']]]
];
