var searchData=
[
  ['printarea',['PrintArea',['../d8/dcb/classHPLFPSDK_1_1Types.html#a198469b911a850c3734c3475fb66aa36',1,'HPLFPSDK::Types::PrintArea()'],['../d9/d49/types_8h.html#a2beaf782c074e33db5f2409114acd8a8',1,'PrintArea():&#160;types.h']]],
  ['printerfamily',['PrinterFamily',['../d8/dcb/classHPLFPSDK_1_1Types.html#a07c901a9f1c77fd9608431b42f9a8835',1,'HPLFPSDK::Types']]],
  ['printingorder',['PrintingOrder',['../d8/dcb/classHPLFPSDK_1_1Types.html#a923b398b18dabb4881b397f708fa3872',1,'HPLFPSDK::Types::PrintingOrder()'],['../d9/d49/types_8h.html#a139f415ddc44043415072575c37eefd6',1,'PrintingOrder():&#160;types.h']]],
  ['printquality',['PrintQuality',['../d8/dcb/classHPLFPSDK_1_1Types.html#ad552a4e641b0051e91022b08521c8ebf',1,'HPLFPSDK::Types::PrintQuality()'],['../d9/d49/types_8h.html#ae0d4958d9283fca9ea6bc70ef91a4895',1,'PrintQuality():&#160;types.h']]]
];
