var searchData=
[
  ['unidirectional',['Unidirectional',['../d8/dcb/classHPLFPSDK_1_1Types.html#a5727c232bd7bc5a9f809b0016564cf16',1,'HPLFPSDK::Types::Unidirectional()'],['../d9/d49/types_8h.html#a5d21690228b6799fa053bf092c79c02b',1,'Unidirectional():&#160;types.h']]]
];
