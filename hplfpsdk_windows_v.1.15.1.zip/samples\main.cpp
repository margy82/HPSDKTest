//////////////////////////////////////////////////////////////////////////////
/**
* @file  main.cpp
* @author Julia Herrero Fernandez julia.herrero.fernandez@hp.com
* @date   Fri Dec  16 11:27:33 CEST 2016
* @brief  C++ CodeSample.
*
* This file contains a menu to call different samples from HPLFPSDK.
* This program recieves as arguments:
*   1- The IP address of the printer
*   2- Its model name
*
* @par &copy; Copyright Hewlett-Packard Company, 2000-2016.
* All rights reserved. Copying or other reproduction of this program except
* for archival purposes is prohibited without written consent of
* Hewlett-Packard Company.
*/
//////////////////////////////////////////////////////////////////////////////

#include <assert.h>
#include <string>
#include "mediaManagerSamples/getMediaInformation.h"
#include "mediaManagerSamples/getMediaInformationCounter.h"
#include "mediaManagerSamples/getSupportedPrintmodes.h"
#include "remoteManagerSamples/cancelPrintJobSample.h"
#include "remoteManagerSamples/deletePrintJobSample.h"
#include "remoteManagerSamples/promotePrintJobSample.h"
#include "remoteManagerSamples/getJobStatusListSample.h"
#include "printingSamples/printSample.h"
#include "infoManagerSamples/EventingSample.h"

// HPLFPSDK LIBRARY INCLUDE
#include "IHplfpsdk.h"

using namespace HPLFPSDK_SAMPLES;


void samplesInfoManager(HPLFPSDK::IDevice* device)
{

    int selection = 0;
    bool exit = false;
    HPLFPSDK::IDevice * printer = device;

    while (exit != true)
    {
        std::cout << "\n\n    Choose a sample:" << std::endl;
        std::cout << "       1 - Ink eventing sample" << std::endl;
        std::cout << "       99- Back to main menu" << std::endl;
        std::cout << "    OPTION : ";
        std::cin >> selection;

        switch (selection)
        {
        case 1:
            std::cout << "    1 - Ink eventing sample" << std::endl;
            //Call to sample eventingSample.cpp
            eventingSample(printer);
            break;
        case 99:
            exit = true;
            break;
        default:
            std::cout << "Invalid option:" << std::endl;
        }
    }
}

void samplesMediaManager(HPLFPSDK::IDevice* device)
{

    int selection = 0;
    bool exit = false;
    HPLFPSDK::IDevice * printer = device;
    std::string mediaID;

    while (exit != true)
    {
        std::cout << "\n\n    Choose a sample:" << std::endl;
        std::cout << "       1 - Get supported print modes sample" << std::endl;
        std::cout << "       2 - Get media information sample" << std::endl;
        std::cout << "       3 - Get media information counter sample" << std::endl;
        std::cout << "       99- Back to main menu" << std::endl;
        std::cout << "    OPTION : ";
        std::cin >> selection;

        switch (selection)
        {
        case 1:
            std::cout << "    1 - Get supported print modes sample for media ID, enter mediaID: ";
            std::cin >> mediaID;
            //Call to sample getSupportedPrintModes.cpp
            getSupportedPrintmodes(printer, mediaID);
            break;
        case 2:
          
            std::cout << "    2 - Get media information sample" << std::endl;
            //Call to sample getMediaInformation.cpp
            getMediaInformation(printer);
            break;
        case 3:
            std::cout << "    3 - Get media information counter sample" << std::endl;
            //Call to sample getMediaInformationCounter.cpp
            getMediaInformationCounter(printer);
            break;
        case 99:
            exit = true;
            break;
        default:
            std::cout << "Invalid option:" << std::endl;
        }
    }
}


void samplesRemoteManager(HPLFPSDK::IDevice* printer)
{

    int selection = 0;
    bool exit = false;

    while (exit != true)
    {
        std::cout << "\n\n    Please, choose the sample you want to execute:" << std::endl;
        std::cout << "       1 - Cancel Print Job sample" << std::endl;
        std::cout << "           NOTE: The printer has to be printing / processing a job" << std::endl;
        std::cout << "       2 - Delete Print Job sample" << std::endl;
        std::cout << "           NOTE: The printer has to have jobs" << std::endl;
        std::cout << "       3 - Get Job Status List sample" << std::endl;
        std::cout << "           NOTE: The printer has to have jobs" << std::endl;
        std::cout << "       4 - Promote Print Job Sample" << std::endl;
        std::cout << "           NOTE: The printer has to have jobs" << std::endl;
        std::cout << "       99- Back to main menu" << std::endl;
        std::cout << "     OPTION : ";
        std::cin >> selection;

        switch (selection)
        {
        case 1:
            std::cout << "    1 - Cancel Print Job Sample\n" << std::endl;
            //Call to sample cancelPrintJobSample.cpp
            cancelPrintJobSample(printer);
            break;
        case 2:
            std::cout << "    2 - Delete Print Job Sample\n" << std::endl;
            //Call to sample deletePrintJobSample.cpp
            deletePrintJobSample(printer);
            break;
        case 3:
            std::cout << "   3 - Get Job Status List Sample\n" << std::endl;
            //Call to sample getJobStatusListSample.cpp
            getJobStatusListSample(printer);
            break;
        case 4:
            std::cout << "   4 - Promote Print Job Sample" << std::endl;
            //Call to sample promotePrintJobSample.cpp
            promotePrintJobSample(printer);
            break;
        case 99:
            exit = true;
            break;
        default:
            std::cout << "Invalid option:" << std::endl;
        }
    }
}

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        std::cout << "You must introduce 2 arguments." << std::endl;
        std::cout << "First argument: IP address" << std::endl;
        std::cout << "Second argument: Model name" << std::endl;
        std::cout << "i.e : samples 127.0.0.1 \"HP DesignJet T1700\"" << std::endl;
        return 1;
    }
    HPLFPSDK::Types::Result result = HPLFPSDK::Types::RESULT_OK;

    // HPLFPSDK LIBRARY CALL TO INITIALIZE THE LIBRARY
    result = hplfpsdk_init();
    assert(result == HPLFPSDK::Types::RESULT_OK);

    HPLFPSDK::IDevice* printer = NULL;

    // HPLFPSDK LIBRARY CALL TO GET NEW PRINTER
    // GIVEN PRINTER IP AND PRINTER MODEL NAME
    // RETURNS AN OBJECT IDEVICE "printer"
    result = hplfpsdk_getNewPrinter(argv[1], argv[2], printer);
    assert(result == HPLFPSDK::Types::RESULT_OK);

    int selection;
    bool exit = false;
    while (exit != true){
        std::cout << "\n\n  ------------------------------------------------------------------\n";
        std::cout << "  ---------------- H P L F P S D K - S A M P L E S -----------------\n";
        std::cout << "  ------------------------------------------------------------------\n";

        std::cout << "\n    Please, choose a category of samples:\n\n" << std::endl;

        std::cout << "       1  -  Media Manager Samples \n\n";
        std::cout << "       2  -  Remote Manager Samples  \n\n";
        std::cout << "       3  -  Info Manager Samples  \n\n";
        std::cout << "       4  -  Accounting Manager Samples  \n\n";
        std::cout << "       5  -  Usage Manager Samples  \n\n";
        std::cout << "       6  -  Printing Samples  \n\n";
        std::cout << "       99 -  QUIT  \n\n";
        std::cout << "    OPTION : ";
        std::cin >> selection;
        std::cout << "\n  ------------------------------------------------------------------\n";

        switch (selection)
        {
        case 1:
            std::cout << "  ------------------------------------------------------------------\n";
            std::cout << "  ------------ M E D I A   M A N A G E R   S A M P L E S -----------\n";
            std::cout << "  ------------------------------------------------------------------\n";
            samplesMediaManager(printer);
            break;
        case 2:
            std::cout << "  ------------------------------------------------------------------\n";
            std::cout << "  ---------- R E M O T E   M A N A G E R   S A M P L E S -----------\n";
            std::cout << "  ------------------------------------------------------------------\n";
            samplesRemoteManager(printer);
            break;
        case 3:
            std::cout << "  ------------------------------------------------------------------\n";
            std::cout << "  ------------ I N F O   M A N A G E R   S A M P L E S -------------\n";
            std::cout << "  ------------------------------------------------------------------\n";
            samplesInfoManager(printer);
            break;
        case 4:
            std::cout << "  ------------------------------------------------------------------\n";
            std::cout << "  ------- A C C O U N T I N G   M A N A G E R   S A M P L E S ------\n";
            std::cout << "  ------------------------------------------------------------------\n";
            break;
        case 5:
            std::cout << "  ------------------------------------------------------------------\n";
            std::cout << "  ------------- U S A G E   M A N A G E R   S A M P L E S ----------\n";
            std::cout << "  ------------------------------------------------------------------\n";
            break;
        case 6:
            std::cout << "  ------------------------------------------------------------------\n";
            std::cout << "  ------------------ P R I N T I N G   S A M P L E S ---------------\n";
            std::cout << "  ------------------------------------------------------------------\n";
            // generate a printable rs file from the source TIF render file
            testJustPrint(printer, "./Tiff_Images/FACES_RGBX_600.TIF", "./Output/FACES_RGBX_600.rs");
            std::cout << "  ------------------------------------------------------------------\n";

            break;
        case 99:
            exit = true;
            break;
        default: std::cout << "\n Invalid selection";
        }
        std::cout << "\n";
    }

    // HPLFPSDK LIBRARY CALL TO DISCARD CREATED PRINTER
    hplfpsdk_discardPrinter(printer);

    // sdk2 library call
    hplfpsdk_terminate();

    return 0;
}
