var searchData=
[
  ['flipedge',['FlipEdge',['../d8/dcb/classHPLFPSDK_1_1Types.html#ae2cdb21c559a1ddb6d777bd71b5c8308',1,'HPLFPSDK::Types::FlipEdge()'],['../d9/d49/types_8h.html#a104bd6613466a930eceb80286350bd08',1,'FlipEdge():&#160;types.h']]],
  ['foldingstyle',['FoldingStyle',['../d8/dcb/classHPLFPSDK_1_1Types.html#af3e6f79620164cad7817055c1eb8ee6f',1,'HPLFPSDK::Types::FoldingStyle()'],['../d9/d49/types_8h.html#af72427fac39f9a46e577d05ef193e819',1,'FoldingStyle():&#160;types.h']]]
];
