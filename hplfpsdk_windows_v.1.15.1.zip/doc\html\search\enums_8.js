var searchData=
[
  ['jobcollate',['JobCollate',['../d8/dcb/classHPLFPSDK_1_1Types.html#a9efb9a35af03fcdaaa46f33040d107f8',1,'HPLFPSDK::Types::JobCollate()'],['../d9/d49/types_8h.html#a5d5ee643a16dea3201638b6aa001657a',1,'JobCollate():&#160;types.h']]],
  ['joblanguage',['JobLanguage',['../d8/dcb/classHPLFPSDK_1_1Types.html#a885eb56f5a87e17c1da55d98c5a3296c',1,'HPLFPSDK::Types']]],
  ['jobpackertype',['JobPackerType',['../d3/d96/classHPLFPSDK_1_1IJobPacker.html#a67ddc0127767e7083ed49b237b941383',1,'HPLFPSDK::IJobPacker']]]
];
