var annotated_dup =
[
    [ "HPLFPSDK", "d0/d8c/namespaceHPLFPSDK.html", "d0/d8c/namespaceHPLFPSDK" ],
    [ "_HPLFPSDK_GUID", "d0/d97/struct__HPLFPSDK__GUID.html", "d0/d97/struct__HPLFPSDK__GUID" ],
    [ "MetricDistance", "d4/dd5/structMetricDistance.html", "d4/dd5/structMetricDistance" ]
];