var searchData=
[
  ['pageid_5ft',['pageid_t',['../d3/d96/classHPLFPSDK_1_1IJobPacker.html#a7bbbe534ae83e2109cb365886bf733ac',1,'HPLFPSDK::IJobPacker']]],
  ['privacypin',['PrivacyPin',['../d8/dcb/classHPLFPSDK_1_1Types.html#af1c003cfb859a18313a83b219675f4fe',1,'HPLFPSDK::Types::PrivacyPin()'],['../d9/d49/types_8h.html#a95864b98b2864b20c377697cf75cc0b2',1,'PrivacyPin():&#160;types.h']]]
];
