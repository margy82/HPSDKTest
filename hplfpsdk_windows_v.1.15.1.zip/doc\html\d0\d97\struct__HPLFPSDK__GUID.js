var struct__HPLFPSDK__GUID =
[
    [ "clock_seq_hi_and_reserved", "d0/d97/struct__HPLFPSDK__GUID.html#a0efcdc70d559bebc97d1c9a5284502a7", null ],
    [ "clock_seq_low", "d0/d97/struct__HPLFPSDK__GUID.html#a80b44432ff2ff91fec0c9bcb49635981", null ],
    [ "node", "d0/d97/struct__HPLFPSDK__GUID.html#af956d08031c0a482dc53ab294cc01b45", null ],
    [ "time_hi_and_version", "d0/d97/struct__HPLFPSDK__GUID.html#a860f0be418c7745047c4fe5a94a323da", null ],
    [ "time_low", "d0/d97/struct__HPLFPSDK__GUID.html#a6a07abc39afe23d0c598c6b10ab5471d", null ],
    [ "time_mid", "d0/d97/struct__HPLFPSDK__GUID.html#a236af0b0c05c59b797c959d5804b6e14", null ]
];