//////////////////////////////////////////////////////////////////////////////
/**
* @file  getMediaInformation.h
* @author Julia Herrero Fernandez julia.herrero.fernandez@hp.com
* @date   Fri Dec  16 11:27:33 CEST 2016
* @brief  C++ CodeSample.
* Sample Code that demostrates the usage of getMediaInformation call of media manager web service
*
* In order to make it clearer this code does not include proper error checking
* (some asserts are include instead) nor user iteraction.
*
* @par &copy; Copyright Hewlett-Packard Company, 2000-2016.
* All rights reserved. Copying or other reproduction of this program except
* for archival purposes is prohibited without written consent of
* Hewlett-Packard Company.
*/
//////////////////////////////////////////////////////////////////////////////

// HPLFPSDK LIBRARY INCLUDE
#include "IHplfpsdk.h"

namespace HPLFPSDK_SAMPLES
{
    int getMediaInformation(HPLFPSDK::IDevice * device);
}

