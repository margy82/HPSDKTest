var searchData=
[
  ['newjob',['newJob',['../d3/d96/classHPLFPSDK_1_1IJobPacker.html#a85c040fd59cdb6bbd4c120083cf7d6b0',1,'HPLFPSDK::IJobPacker::newJob()'],['../d6/dc7/classHPLFPSDK_1_1ISolPacker.html#a051358ec33390fa82d266b206ac3cd97',1,'HPLFPSDK::ISolPacker::newJob(IJobSettings *settings, ISolPacker::ISolMemoryHandler *mhdl, transmissionStatusCallback callback, void *userData)=0'],['../d6/dc7/classHPLFPSDK_1_1ISolPacker.html#a010e5654ca6b75cb5aef0793b9641064',1,'HPLFPSDK::ISolPacker::newJob(IJobSettings *settings, IMemoryHandler *mhdl, transmissionStatusCallback callback, void *userData)']]],
  ['node',['node',['../d0/d97/struct__HPLFPSDK__GUID.html#af956d08031c0a482dc53ab294cc01b45',1,'_HPLFPSDK_GUID']]],
  ['numbytes_5f',['numBytes_',['../df/dcf/classHPLFPSDK_1_1IJobPacker_1_1Preview.html#aaa96cd96f87b42aa0733196ff93614bb',1,'HPLFPSDK::IJobPacker::Preview']]],
  ['numcopies',['NumCopies',['../d8/dcb/classHPLFPSDK_1_1Types.html#a51c4781d42c5da9700c0f3cb2bd5eab3',1,'HPLFPSDK::Types::NumCopies()'],['../d9/d49/types_8h.html#aa963a440aaa1994616f4794f408ad4a8',1,'NumCopies():&#160;types.h']]],
  ['numplane_5f',['numPlane_',['../d5/d35/classHPLFPSDK_1_1IJobPacker_1_1RS__buffer.html#a9ec5371448dd6fe3ad412ce22db0ea15',1,'HPLFPSDK::IJobPacker::RS_buffer']]]
];
