//////////////////////////////////////////////////////////////////////////////
/**
* @file  getJobStatusListSample.cpp
* @author Julia Herrero Fernandez julia.herrero.fernandez@hp.com
* @date   Fri Dec  16 11:27:33 CEST 2016
* @brief  C++ CodeSample.
* Sample Code that demostrates the usage of getJobStatusList call of remote manager web service.
*
* getJobStatusList retrieves the status from all the jobs stored in the printer.
* getjobStatusList retrieves an array of chars in XML format with the jobs status information.
* This allocated memory shall be deleted using hplfpsdk_deleteBuffer() interface.
*
* In order to make it clearer this code does not include proper error checking
* (some asserts are include instead) nor user iteraction.
*
*
* @par &copy; Copyright Hewlett-Packard Company, 2000-2016.
* All rights reserved. Copying or other reproduction of this program except
* for archival purposes is prohibited without written consent of
* Hewlett-Packard Company.
*/
//////////////////////////////////////////////////////////////////////////////

#include "getJobStatusListSample.h"

#include <assert.h>
#include <string>

int HPLFPSDK_SAMPLES::getJobStatusListSample(HPLFPSDK::IDevice* printer)
{
       
    HPLFPSDK::Types::Result result = HPLFPSDK::Types::RESULT_OK;

    //GETTING REMOTE MANAGER OBJECT
    HPLFPSDK::IRemoteManager *remoteManager_ = printer->getRemoteManager();

    char *jobStatusList = NULL;
    size_t longLength = 0;
    result = remoteManager_->getJobStatusList(&jobStatusList, longLength);
    if (result == HPLFPSDK::Types::RESULT_OK)
    {
        //PRINT TO SCREEN ALL MEDIAINFORMATIONCOUNTER
        std::cout << jobStatusList << std::endl;
        //DELETE BUFFER
        hplfpsdk_deleteBuffer(&jobStatusList);
    }
    else
    {
        std::cout << "Error: " << result << std::endl;
    }

    return 0;
}
