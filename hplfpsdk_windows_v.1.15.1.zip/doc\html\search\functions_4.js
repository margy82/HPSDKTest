var searchData=
[
  ['formfeedandcut',['formFeedAndCut',['../d0/dbc/classHPLFPSDK_1_1IRemoteManager.html#af56aa065ff2289cc7d13e7614873cbef',1,'HPLFPSDK::IRemoteManager']]]
];
