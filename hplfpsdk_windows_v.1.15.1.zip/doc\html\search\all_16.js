var searchData=
[
  ['xbgr',['xBGR',['../d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81adeddb709ba5e3eba2f495651ba112266',1,'HPLFPSDK::Types']]],
  ['xrgb',['xRGB',['../d8/dcb/classHPLFPSDK_1_1Types.html#a5aeffa5e1fa86c1f17607b7129349d81a5104fe04d579067edbe3917bcdddbe8b',1,'HPLFPSDK::Types']]]
];
